# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: progression-a67.spec.ts >> A67 encounter full journey es diagon-alley
- Location: tests/browser-trial/progression-a67.spec.ts:158:5

# Error details

```
Error: expect(received).toBeLessThanOrEqual(expected)

Expected: <= 863
Received:    922
```

# Test source

```ts
  1   | import { test, expect, type Page } from '@playwright/test';
  2   | import { Pool } from 'pg';
  3   | import { mkdir, writeFile } from 'node:fs/promises';
  4   | import { resolve } from 'node:path';
  5   | import { changeLanguage, startExpedition } from './game-fixture';
  6   | import { readGame, expectMapFits } from './route-helpers';
  7   | import { preparedRoutePath } from '../support/prepared-route';
  8   | import { previewEncounterTrade } from '../../src/arcana/domain/exploration/encounter-trades';
  9   | import type { Language } from '../../src/arcana/domain/collection/wizards';
  10  | import type { NodeKind } from '../../src/arcana/domain/exploration/route';
  11  | 
  12  | const root = resolve('docs/arcana/progression-increment-2026-10-16/evidence/browser');
  13  | const sizes = [
  14  |   { width: 1280, height: 900 },
  15  |   { width: 390, height: 844 },
  16  |   { width: 865, height: 1079 },
  17  | ];
  18  | const pool = new Pool({
  19  |   host: '127.0.0.1',
  20  |   port: 55432,
  21  |   user: 'arcana_dev',
  22  |   password: 'arcana-local-development',
  23  |   database: 'arcana_dev',
  24  |   max: 2,
  25  | });
  26  | const created = new Set<string>();
  27  | test.afterAll(async () => {
  28  |   if (created.size)
  29  |     await pool.query('DELETE FROM arcana_accounts WHERE player_id=ANY($1::text[])', [[...created]]);
  30  |   await pool.end();
  31  | });
  32  | async function capture(page: Page, name: string, scrollAllowed = false) {
  33  |   await mkdir(root, { recursive: true });
  34  |   const geometry = [];
  35  |   for (const size of sizes) {
  36  |     await page.setViewportSize(size);
  37  |     const dialog = page.locator('.node-event-dialog[open]');
  38  |     if (await dialog.count()) {
  39  |       const metrics = await dialog.evaluate((el) => ({
  40  |         width: el.clientWidth,
  41  |         scrollWidth: el.scrollWidth,
  42  |         height: el.clientHeight,
  43  |         scrollHeight: el.scrollHeight,
  44  |       }));
  45  |       expect(metrics.scrollWidth).toBeLessThanOrEqual(metrics.width + 1);
> 46  |       if (!scrollAllowed) expect(metrics.scrollHeight).toBeLessThanOrEqual(metrics.height + 1);
      |                                                        ^ Error: expect(received).toBeLessThanOrEqual(expected)
  47  |       geometry.push({ ...size, ...metrics });
  48  |     }
  49  |     if (process.env.ARCANA_CAPTURE_EVIDENCE === '1') {
  50  |       await page.screenshot({
  51  |         path: resolve(root, `${test.info().project.name}-${name}-${size.width}.png`),
  52  |         fullPage: false,
  53  |         animations: 'disabled',
  54  |       });
  55  |     }
  56  |   }
  57  |   await page.setViewportSize(sizes[0]);
  58  |   return geometry;
  59  | }
  60  | async function enter(page: Page, language: Language, pack = 'diagon-alley', start = true) {
  61  |   await page.addInitScript(
  62  |     (pack) => localStorage.setItem('arcana.presentation.content-pack.v1', pack),
  63  |     pack,
  64  |   );
  65  |   await page.goto('/');
  66  |   if (language === 'en') await changeLanguage(page, language);
  67  |   await page.locator('.portal-enter').click();
  68  |   await expect(page.locator('[data-expedition-preparation="new"]')).toBeVisible();
  69  |   created.add((await readGame(page)).playerId);
  70  |   if (start) await startExpedition(page, language);
  71  | }
  72  | async function closeReplay(page: Page, language: Language) {
  73  |   if (!(await page.locator('.arena-a63').count())) return;
  74  |   const skip = page.getByRole('button', {
  75  |     name: language === 'es' ? 'Omitir reproducción' : 'Skip playback',
  76  |     exact: true,
  77  |   });
  78  |   if (await skip.isEnabled()) await skip.click();
  79  |   await page
  80  |     .getByRole('button', {
  81  |       name: language === 'es' ? 'Volver al mapa' : 'Back to map',
  82  |       exact: true,
  83  |     })
  84  |     .click();
  85  |   await expect(page.locator('[data-map-phase="route"]')).toBeVisible();
  86  | }
  87  | async function confirmEvent(page: Page, language: Language) {
  88  |   const pact = page.locator('[data-pact-candidate]');
  89  |   if (await pact.count()) {
  90  |     if (await pact.first().isEnabled()) await pact.first().click();
  91  |     else await page.locator('[data-pact-choice="pass"]').click();
  92  |     const replacements = page.locator('[data-tactical-pact] [data-visual-value]');
  93  |     if (!(await page.locator('.node-confirm-action').isEnabled()) && (await replacements.count()))
  94  |       await replacements.first().click();
  95  |   }
  96  |   const pass = page.locator('[data-encounter-choice="pass"]');
  97  |   if (await pass.count()) await pass.click();
  98  |   await page.locator('.node-confirm-action').click();
  99  |   await expect(page.locator('.node-event-dialog')).toHaveCount(0);
  100 |   await closeReplay(page, language);
  101 | }
  102 | async function reach(page: Page, kind: NodeKind, language: Language) {
  103 |   const run = (await readGame(page)).exploration!.run!;
  104 |   const path = preparedRoutePath(run, kind);
  105 |   for (const id of path.slice(0, -1)) {
  106 |     await page.locator(`[data-node="${id}"]`).click();
  107 |     await confirmEvent(page, language);
  108 |   }
  109 |   return path.at(-1)!;
  110 | }
  111 | /** Declared adverse-condition fixture, scoped only to the account created by this test.
  112 |  * No currencies, rewards, inventory or campaign snapshots are changed. */
  113 | async function conditionFixture(page: Page) {
  114 |   const state = await readGame(page);
  115 |   expect(created.has(state.playerId)).toBe(true);
  116 |   const currentRun = structuredClone(state.exploration!.run!);
  117 |   const run = {
  118 |     ...currentRun,
  119 |     members: currentRun.members.map((member) => ({
  120 |       ...member,
  121 |       unit: { ...member.unit, hp: member.unit.maxHp * 0.5, mana: member.unit.maxMana * 0.5 },
  122 |     })),
  123 |   };
  124 |   const client = await pool.connect();
  125 |   try {
  126 |     await client.query('BEGIN');
  127 |     const locked = await client.query(
  128 |       'SELECT revision FROM arcana_accounts WHERE player_id=$1 FOR UPDATE',
  129 |       [state.playerId],
  130 |     );
  131 |     expect(Number(locked.rows[0].revision)).toBe(state.revision);
  132 |     const changed = await client.query(
  133 |       'UPDATE arcana_exploration SET run_state=$1::jsonb WHERE player_id=$2 AND run_id=$3',
  134 |       [JSON.stringify(run), state.playerId, run.id],
  135 |     );
  136 |     expect(changed.rowCount).toBe(1);
  137 |     await client.query('UPDATE arcana_accounts SET revision=revision+1 WHERE player_id=$1', [
  138 |       state.playerId,
  139 |     ]);
  140 |     await client.query('COMMIT');
  141 |   } catch (error) {
  142 |     await client.query('ROLLBACK');
  143 |     throw error;
  144 |   } finally {
  145 |     client.release();
  146 |   }
```