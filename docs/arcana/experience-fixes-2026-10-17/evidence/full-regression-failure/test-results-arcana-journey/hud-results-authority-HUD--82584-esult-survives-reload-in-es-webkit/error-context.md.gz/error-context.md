# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: hud-results.spec.ts >> authority HUD and boss result survives reload in es
- Location: tests/browser-trial/hud-results.spec.ts:7:3

# Error details

```
Test timeout of 30000ms exceeded.
```

```
Error: locator.click: Test timeout of 30000ms exceeded.
Call log:
  - waiting for getByRole('dialog').getByRole('button', { name: 'Actualizar estado', exact: true })

```

# Page snapshot

```yaml
- generic [ref=e3]:
  - link "Saltar al contenido" [ref=e4]:
    - /url: "#content"
  - banner [ref=e5]:
    - heading "El Pasaje Torcido Descubrimiento" [level=1] [ref=e6]:
      - text: El Pasaje Torcido
      - generic [ref=e7]: Descubrimiento
    - generic [ref=e8]:
      - status [ref=e9]
      - button "Una noche encantada" [ref=e10] [cursor=pointer]
  - status [ref=e13]: Nodo 6 resuelto. El resultado está confirmado y guardado.
  - generic [ref=e14]:
    - strong [ref=e15]:
      - generic "Coronas" [ref=e17]: "80"
    - generic [ref=e18]:
      - generic [ref=e19]:
        - generic [ref=e21]: Esencia
        - text: 45 / 50
        - meter "Esencia Rúnica" [ref=e22]
      - generic [ref=e23]: Próximo punto a las 19:32:19.
      - button "Actualizar Esencia" [disabled] [ref=e24]
    - generic [ref=e27]:
      - strong [aria-hidden] [ref=e29]: "0"
      - generic [ref=e30]: 0 Llaves de Oro
  - main [ref=e31]:
    - status [ref=e32]
    - generic [ref=e33]:
      - generic:
        - complementary "Siguiente objetivo":
          - generic:
            - heading "Elige tu siguiente paso" [level=3]
            - group [ref=e34]:
              - generic "Siguiente objetivo" [ref=e35] [cursor=pointer]: "?"
            - 'generic "Etapas recorridas: 6 de 7"': 6 / 7
      - region "Resultado de nodo confirmado" [ref=e36]:
        - group [ref=e37]:
          - generic "Resultado de nodo confirmado" [ref=e38] [cursor=pointer]:
            - generic [aria-hidden] [ref=e42]: ⌄
      - region "Tu Equipo" [ref=e43]:
        - heading "Tu Equipo" [level=2] [ref=e44]
        - button "Aprendiz de Alquimia" [ref=e46] [cursor=pointer]:
          - generic [ref=e48]: Copia propia
          - meter "Vida de Aprendiz de Alquimia" [ref=e51]
        - button "Tejedora de Runas" [ref=e53] [cursor=pointer]:
          - generic [ref=e55]: Aliado temporal
          - meter "Vida de Tejedora de Runas" [ref=e58]
        - button "Nicolás Flamel" [ref=e60] [cursor=pointer]:
          - generic [ref=e62]: Aliado temporal
          - meter "Vida de Nicolás Flamel" [ref=e65]
        - button "Tejedora de Runas" [ref=e67] [cursor=pointer]:
          - generic [ref=e69]: Aliado temporal
          - meter "Vida de Tejedora de Runas" [ref=e72]
        - button "Prepara tu expedición" [ref=e73] [cursor=pointer]
      - button "Ver lista de nodos" [ref=e76] [cursor=pointer]
      - generic [ref=e79]:
        - generic "Inicio"
        - button "Pacto Mágico · etapa 1, opción 1 · Visitado" [disabled] [ref=e81]:
          - generic [aria-hidden] [ref=e84]: ✓
          - strong [ref=e85]: Pacto Mágico
          - generic [ref=e86]: Visitado
        - button "Cofre de Botín · etapa 2, opción 1 · Bloqueado" [ref=e88] [cursor=pointer]:
          - strong [ref=e91]: Cofre de Botín
          - generic [ref=e92]: Bloqueado
        - button "Pacto Mágico · etapa 2, opción 2 · Visitado" [disabled] [ref=e94]:
          - generic [aria-hidden] [ref=e97]: ✓
          - strong [ref=e98]: Pacto Mágico
          - generic [ref=e99]: Visitado
        - button "Pacto Mágico · etapa 3, opción 1 · Visitado" [disabled] [ref=e101]:
          - generic [aria-hidden] [ref=e104]: ✓
          - strong [ref=e105]: Pacto Mágico
          - generic [ref=e106]: Visitado
        - button "Duelo Arcano · etapa 3, opción 2 · Bloqueado" [ref=e108] [cursor=pointer]:
          - strong [ref=e111]: Duelo Arcano
          - generic [ref=e112]: Bloqueado
        - button "Duelo Arcano · etapa 3, opción 3 · Bloqueado" [ref=e114] [cursor=pointer]:
          - strong [ref=e117]: Duelo Arcano
          - generic [ref=e118]: Bloqueado
        - button "Cofre de Botín · etapa 4, opción 1 · Visitado" [disabled] [ref=e120]:
          - generic [aria-hidden] [ref=e123]: ✓
          - strong [ref=e124]: Cofre de Botín
          - generic [ref=e125]: Visitado
        - button "Refugio Alquímico · etapa 4, opción 2 · Bloqueado" [ref=e127] [cursor=pointer]:
          - strong [ref=e130]: Refugio Alquímico
          - generic [ref=e131]: Bloqueado
        - button "Refugio Alquímico · etapa 4, opción 3 · Bloqueado" [ref=e133] [cursor=pointer]:
          - strong [ref=e136]: Refugio Alquímico
          - generic [ref=e137]: Bloqueado
        - button "Duelo Arcano · etapa 5, opción 1 · Bloqueado" [ref=e139] [cursor=pointer]:
          - generic: Vanguardia · iniciativa
          - strong [ref=e142]: Duelo Arcano
          - generic [ref=e143]: Bloqueado
        - button "Cofre de Botín · etapa 5, opción 2 · Bloqueado" [ref=e145] [cursor=pointer]:
          - strong [ref=e148]: Cofre de Botín
          - generic [ref=e149]: Bloqueado
        - button "Duelo Arcano · etapa 5, opción 3 · Visitado" [disabled] [ref=e151]:
          - generic: Fuego · quemadura
          - generic [aria-hidden] [ref=e154]: ✓
          - strong [ref=e155]: Duelo Arcano
          - generic [ref=e156]: Visitado
        - button "Encuentro · etapa 6, opción 1 · Bloqueado" [ref=e158] [cursor=pointer]:
          - strong [ref=e161]: Encuentro
          - generic [ref=e162]: Bloqueado
        - button "Encuentro · etapa 6, opción 2 · Bloqueado" [ref=e164] [cursor=pointer]:
          - strong [ref=e167]: Encuentro
          - generic [ref=e168]: Bloqueado
        - button "Refugio Alquímico · etapa 6, opción 3 · Visitado" [disabled] [ref=e170]:
          - generic [aria-hidden] [ref=e173]: ✓
          - strong [ref=e174]: Refugio Alquímico
          - generic [ref=e175]: Visitado
        - button "Jefe de Zona · etapa 7, opción 1 · Disponible" [ref=e177] [cursor=pointer]:
          - generic [aria-hidden] [ref=e180]: ▴
          - strong [ref=e181]: Jefe de Zona
          - generic [ref=e182]: Disponible
          - generic [ref=e183]: Combate · 5 Esencia
      - dialog "Confirmación de nodo" [ref=e184]:
        - button "Ajustes" [ref=e185] [cursor=pointer]
        - heading "Jefe de Zona" [level=3] [ref=e188]
        - paragraph [ref=e189]: Consume 5 Esencia. Combate automático con el equipo actual.
        - generic [ref=e190]:
          - region "Circe" [ref=e191]:
            - generic [ref=e192]:
              - generic [ref=e193]:
                - heading "Circe" [level=4] [ref=e194]
                - generic [ref=e195]: Fuego
                - generic [ref=e196]: 3 · Rivales
              - generic "Rivales" [ref=e197]:
                - generic [ref=e202]:
                  - generic [ref=e203]: Rival
                  - generic [ref=e204]: Neutral
                - generic [ref=e207]:
                  - generic [ref=e208]: Rival
                  - generic [ref=e209]: Neutral
            - group [ref=e210]:
              - generic "Conocer al rival" [ref=e211] [cursor=pointer]
          - generic "Botín si ganas; entrega fija en cofres" [ref=e214]:
            - generic "Coronas" [ref=e215]:
              - strong [ref=e217]: "50"
            - generic "Llaves de Oro" [ref=e218]:
              - strong [ref=e220]: "1"
            - strong [ref=e223]: "1"
            - generic [ref=e224]: 50 Coronas, 1 llaves, 1 sapos, 0 grageas.
        - generic [ref=e225]:
          - region "Tu equipo" [ref=e226]:
            - heading "Tu equipo" [level=4] [ref=e227]
            - generic [ref=e228]:
              - 'button "Preparar Aprendiz de Alquimia, puesto 1. Copia propia. PV 78/100, PM 35/40. Equipo: Varita de Abedul · Sin núcleo · +2 · ×1, Céfiro Cadete." [disabled] [ref=e229]':
                - generic [aria-hidden] [ref=e232]: "1"
                - generic [aria-hidden] [ref=e234]: Aprendiz de Alquimia
                - generic [aria-hidden] [ref=e235]:
                  - generic [ref=e236]: PV 78/100
                  - generic [ref=e237]: PM 35/40
              - button "Preparar Tejedora de Runas, puesto 2. Solo esta expedición. PV 80/80, PM 35/40." [disabled] [ref=e243]:
                - generic [aria-hidden] [ref=e246]: "2"
                - generic [aria-hidden] [ref=e248]: Tejedora de Runas
                - generic [aria-hidden] [ref=e249]:
                  - generic [ref=e250]: PV 80/80
                  - generic [ref=e251]: PM 35/40
              - button "Preparar Nicolás Flamel, puesto 3. Solo esta expedición. PV 95/95, PM 36/40." [disabled] [ref=e252]:
                - generic [aria-hidden] [ref=e255]: "3"
                - generic [aria-hidden] [ref=e257]: Nicolás Flamel
                - generic [aria-hidden] [ref=e258]:
                  - generic [ref=e259]: PV 95/95
                  - generic [ref=e260]: PM 36/40
              - button "Preparar Tejedora de Runas, puesto 4. Solo esta expedición. PV 80/80, PM 35/40." [disabled] [ref=e261]:
                - generic [aria-hidden] [ref=e264]: "4"
                - generic [aria-hidden] [ref=e266]: Tejedora de Runas
                - generic [aria-hidden] [ref=e267]:
                  - generic [ref=e268]: PV 80/80
                  - generic [ref=e269]: PM 35/40
            - button "Preparar equipo" [disabled] [ref=e270]
            - group [ref=e272]:
              - generic "Sinergias del equipo" [ref=e273] [cursor=pointer]:
                - generic [ref=e275]:
                  - text: Alquimia
                  - strong [ref=e276]: III
          - group [ref=e277]:
            - 'generic "Preparar Grageas. Reserva: 2." [ref=e278] [cursor=pointer]':
              - generic [ref=e280]:
                - generic [ref=e281]: Grageas del Azar
                - strong [aria-hidden] [ref=e282]: ×2
              - text: ⌄
        - generic [ref=e283]:
          - alert [ref=e284]: No hay suficiente Esencia Rúnica. Actualiza la lectura y espera la regeneración antes de confirmar otro duelo.
          - button "Volver a consultar" [ref=e286] [cursor=pointer]
        - generic [ref=e287]:
          - button "Desafiar al jefe" [disabled] [ref=e288]:
            - generic "Consume 5 Esencia. Combate automático con el equipo actual." [ref=e291]:
              - strong [ref=e293]: "5"
          - button "Cerrar" [ref=e294] [cursor=pointer]:
            - generic [aria-hidden] [ref=e295]: ×
  - navigation "Navegación principal" [ref=e296]:
    - button "Mapa" [ref=e297] [cursor=pointer]
    - button "Cromodex" [ref=e300] [cursor=pointer]
    - button "Bazar" [ref=e303] [cursor=pointer]
    - button "Misiones" [ref=e306] [cursor=pointer]
```

# Test source

```ts
  1   | import { text } from '../../src/arcana/presentation/translations';
  2   | import { startExpedition } from './game-fixture';
  3   | import { changeLanguage } from './game-fixture';
  4   | import { pathTo, confirmEvent, readGame } from './route-helpers';
  5   | import { test, expect } from './game-fixture';
  6   | for (const language of ['es', 'en'] as const)
  7   |   test(`authority HUD and boss result survives reload in ${language}`, async ({ page }) => {
  8   |     const en = language === 'en';
  9   |     const button = (es: string, english: string) =>
  10  |       page.getByRole('button', { name: en ? english : es, exact: true });
  11  |     await page.goto('/');
  12  |     if (en) await changeLanguage(page, 'en');
  13  |     await button('Comenzar ensayo local', 'Start local trial').click();
  14  |     const energy = page.getByRole('meter', {
  15  |       name: en ? 'Runic Essence' : 'Esencia Rúnica',
  16  |       exact: true,
  17  |     });
  18  |     await expect(energy).toHaveAttribute('value', '50');
  19  |     await startExpedition(page, language);
  20  |     await expect(page.locator('.branch-map')).toBeVisible();
  21  |     // This checks a saved victory receipt; choose the complete surviving path before branching.
  22  |     // Optimizing only to an intermediate encounter can strand this fixture before the boss.
  23  |     const path = await pathTo(page, 'boss');
  24  |     for (const id of path) {
  25  |       const kind = (await readGame(page)).exploration!.run!.graph.nodes.find(
  26  |         (n) => n.id === id,
  27  |       )!.kind;
  28  |       await page.locator(`[data-node="${id}"]`).click();
  29  |       const before =
  30  |         kind === 'encounter' ? (await (await page.request.get('/api/state')).json()).state : null;
  31  |       if (kind === 'encounter') {
  32  |         if (await page.locator('[data-encounter-offer]').count()) {
  33  |           await expect(
  34  |             page.locator('[data-encounter-choice]:not([data-encounter-choice="pass"])'),
  35  |           ).toHaveCount(2);
  36  |           await expect(page.locator('.node-confirm-action')).toBeDisabled();
  37  |         } else {
  38  |           await page.locator('.node-help summary').click();
  39  |           await expect(page.getByRole('dialog')).toContainText(
  40  |             en ? 'This encounter may grant loot' : 'Este encuentro puede entregar botín',
  41  |           );
  42  |         }
  43  |         await button('Cancelar', 'Cancel').click();
  44  |         expect((await (await page.request.get('/api/state')).json()).state).toEqual(before);
  45  |         await page.locator(`[data-node="${id}"]`).click();
  46  |       }
  47  |       if (kind === 'boss') {
  48  |         const beforeRejection = (await (await page.request.get('/api/state')).json()).state;
  49  |         const reject = async (route: import('@playwright/test').Route) =>
  50  |           route.fulfill({
  51  |             status: 409,
  52  |             contentType: 'application/json',
  53  |             body: JSON.stringify({
  54  |               error: { code: 'INSUFFICIENT_ESSENCE', recoverWithSameKey: false },
  55  |             }),
  56  |           });
  57  |         await page.route('**/api/nodes/advance', reject);
  58  |         await page.locator('.node-confirm-action').click();
  59  |         await expect(page.getByRole('dialog').getByRole('alert')).toContainText(
  60  |           en ? 'There is not enough Runic Essence.' : 'No hay suficiente Esencia Rúnica.',
  61  |         );
  62  |         expect((await (await page.request.get('/api/state')).json()).state).toEqual(
  63  |           beforeRejection,
  64  |         );
  65  |         await page.unroute('**/api/nodes/advance', reject);
  66  |         await page
  67  |           .getByRole('dialog')
  68  |           .getByRole('button', { name: en ? 'Refresh state' : 'Actualizar estado', exact: true })
> 69  |           .click();
      |            ^ Error: locator.click: Test timeout of 30000ms exceeded.
  70  |         await expect(page.getByRole('dialog')).toHaveCount(0);
  71  |         await page.locator(`[data-node="${id}"]`).click();
  72  |       }
  73  |       await confirmEvent(page, language);
  74  |       if (
  75  |         kind === 'encounter' &&
  76  |         (await readGame(page)).receipts.at(-1)?.kind === 'advance-node' &&
  77  |         !(
  78  |           (await readGame(page)).receipts.at(
  79  |             -1,
  80  |           ) as import('../../src/arcana/application/run-contracts').NodeReceipt
  81  |         ).encounter
  82  |       ) {
  83  |         const saved = await readGame(page);
  84  |         await page.locator('.receipt-disclosure > summary').click();
  85  |         await expect(page.locator('.receipt-body')).toContainText(text(language, 'nodePassed'));
  86  |         await page.reload();
  87  |         await expect(page.locator('.branch-map')).toBeVisible();
  88  |         expect(await readGame(page)).toEqual(saved);
  89  |         await changeLanguage(page, en ? 'es' : 'en');
  90  |         expect(await readGame(page)).toEqual(saved);
  91  |         await changeLanguage(page, language);
  92  |       } else if (kind === 'encounter') {
  93  |         await page.locator('.receipt-disclosure > summary').click();
  94  |         const region = page.getByRole('region', {
  95  |           name: en ? 'Encounter outcome' : 'Resultado del encuentro',
  96  |           exact: true,
  97  |         });
  98  |         await expect(region).toBeVisible();
  99  |         const after = (await (await page.request.get('/api/state')).json()).state;
  100 |         const receipt = after.receipts.find(
  101 |           (r: { request?: { nodeId?: string } }) => r.request?.nodeId === id,
  102 |         );
  103 |         const resolution = receipt.encounter.resolution;
  104 |         await expect(region).toContainText(resolution.narrative.text[language]);
  105 |         await expect(region).toHaveAttribute('data-encounter-effect', resolution.effect.kind);
  106 |         expect(after.inventory.essence.points).toBe(before?.inventory.essence.points ?? 50);
  107 |         await page.reload();
  108 |         await page.locator('.receipt-disclosure > summary').click();
  109 |         await expect(region).toContainText(resolution.narrative.text[language]);
  110 |         await changeLanguage(page, en ? 'es' : 'en');
  111 |         await expect(
  112 |           page.getByRole('region', {
  113 |             name: en ? 'Resultado del encuentro' : 'Encounter outcome',
  114 |             exact: true,
  115 |           }),
  116 |         ).toContainText(resolution.narrative.text[en ? 'es' : 'en']);
  117 |         await changeLanguage(page, language);
  118 |         expect((await (await page.request.get('/api/state')).json()).state).toEqual(after);
  119 |         await button('Volver a la ruta', 'Return to route').click();
  120 |       }
  121 |       if (id === 'pasaje:0:0') {
  122 |         await expect(
  123 |           page.getByRole('region', {
  124 |             name: en ? 'Confirmed node result' : 'Resultado de nodo confirmado',
  125 |             exact: true,
  126 |           }),
  127 |         ).toContainText(en ? 'Magic Pact' : 'Pacto Mágico');
  128 |         await expect
  129 |           .poll(async () =>
  130 |             page.locator('.node-result').evaluate((region) => {
  131 |               const bounds = region.getBoundingClientRect(),
  132 |                 nav = document.querySelector('nav')!.getBoundingClientRect();
  133 |               return bounds.top >= 0 && bounds.bottom <= nav.top;
  134 |             }),
  135 |           )
  136 |           .toBe(true);
  137 |       }
  138 |       if (kind === 'duel') await button('Volver al mapa', 'Back to map').click();
  139 |     }
  140 |     await expect(
  141 |       page.getByRole('heading', { name: en ? 'Combat Arena' : 'Arena de Combate', exact: true }),
  142 |     ).toBeVisible();
  143 |     await button('Volver al mapa', 'Back to map').click();
  144 |     await page.locator('.closure-history > summary').click();
  145 |     await page.locator('.receipt-disclosure > summary').click();
  146 |     const result = page.getByRole('region', {
  147 |       name: en ? 'Confirmed node result' : 'Resultado de nodo confirmado',
  148 |       exact: true,
  149 |     });
  150 |     await expect(result).toContainText(en ? '50 Crowns' : '50 Coronas');
  151 |     await expect(result).toContainText(en ? '1 Gold Key' : '1 Llave de Oro');
  152 |     await expect(result).toContainText(
  153 |       en
  154 |         ? 'The next location unlock is saved.'
  155 |         : 'El desbloqueo de la siguiente localización está guardado.',
  156 |     );
  157 |     const resolved = await readGame(page);
  158 |     const combatCount = resolved.receipts.filter(
  159 |       (r) => r.kind === 'advance-node' && r.battle,
  160 |     ).length;
  161 |     await expect(energy).toHaveAttribute('value', String(50 - combatCount * 5));
  162 |     const read = async () => (await (await page.request.get('/api/state')).json()).state;
  163 |     const before = await read();
  164 |     await button('Actualizar Esencia', 'Refresh Essence').click();
  165 |     expect(await read()).toEqual(before);
  166 |     await page.reload();
  167 |     await page.locator('.closure-history > summary').click();
  168 |     await expect(result).toContainText(en ? 'Zone Boss' : 'Jefe de Zona');
  169 |     await page.locator('.receipt-disclosure > summary').click();
```