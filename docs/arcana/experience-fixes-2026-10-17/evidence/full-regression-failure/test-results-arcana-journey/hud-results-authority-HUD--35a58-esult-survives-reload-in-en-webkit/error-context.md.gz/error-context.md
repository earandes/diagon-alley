# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: hud-results.spec.ts >> authority HUD and boss result survives reload in en
- Location: tests/browser-trial/hud-results.spec.ts:7:3

# Error details

```
Test timeout of 30000ms exceeded.
```

```
Error: locator.click: Test timeout of 30000ms exceeded.
Call log:
  - waiting for getByRole('dialog').getByRole('button', { name: 'Refresh state', exact: true })

```

# Page snapshot

```yaml
- generic [ref=f2e3]:
  - link "Skip to content" [ref=f2e4]:
    - /url: "#content"
  - banner [ref=f2e5]:
    - heading "The Crooked Passage Discovery" [level=1] [ref=f2e6]:
      - text: The Crooked Passage
      - generic [ref=f2e7]: Discovery
    - generic [ref=f2e8]:
      - status [ref=f2e9]
      - button "An enchanted night" [ref=f2e10] [cursor=pointer]
  - status [ref=f2e13]
  - generic [ref=f2e14]:
    - strong [ref=f2e15]:
      - generic "Crowns" [ref=f2e17]: "50"
    - generic [ref=f2e18]:
      - generic [ref=f2e19]:
        - generic [ref=f2e21]: Essence
        - text: 50 / 50
        - meter "Runic Essence" [ref=f2e22]
      - generic [ref=f2e23]: Essence is full.
      - button "Refresh Essence" [disabled] [ref=f2e24]
    - generic [ref=f2e27]:
      - strong [aria-hidden] [ref=f2e29]: "0"
      - generic [ref=f2e30]: 0 Gold Keys
  - main [ref=f2e31]:
    - status [ref=f2e32]
    - generic [ref=f2e33]:
      - generic:
        - complementary "Next objective":
          - generic:
            - heading "Choose your next step" [level=3]
            - group [ref=f2e34]:
              - generic "Next objective" [ref=f2e35] [cursor=pointer]: "?"
            - 'generic "Stages visited: 6 of 7"': 6 / 7
      - region "Confirmed node result" [ref=f2e36]:
        - group [ref=f2e37]:
          - generic "Confirmed node result" [ref=f2e38] [cursor=pointer]:
            - generic [aria-hidden] [ref=f2e42]: ⌄
      - region "Your Team" [ref=f2e43]:
        - heading "Your Team" [level=2] [ref=f2e44]
        - button "Alchemy Apprentice" [ref=f2e46] [cursor=pointer]:
          - generic [ref=f2e48]: Owned copy
          - meter "Health of Alchemy Apprentice" [ref=f2e51]
        - button "Rune Weaver" [ref=f2e53] [cursor=pointer]:
          - generic [ref=f2e55]: Temporary ally
          - meter "Health of Rune Weaver" [ref=f2e58]
        - button "Nicolas Flamel" [ref=f2e60] [cursor=pointer]:
          - generic [ref=f2e62]: Temporary ally
          - meter "Health of Nicolas Flamel" [ref=f2e65]
        - button "Rune Weaver" [ref=f2e67] [cursor=pointer]:
          - generic [ref=f2e69]: Temporary ally
          - meter "Health of Rune Weaver" [ref=f2e72]
        - button "Prepare your expedition" [ref=f2e73] [cursor=pointer]
      - button "View node list" [ref=f2e76] [cursor=pointer]
      - generic [ref=f2e79]:
        - generic "Start"
        - button "Magic Pact · stage 1, option 1 · Visited" [disabled] [ref=f2e81]:
          - generic [aria-hidden] [ref=f2e84]: ✓
          - strong [ref=f2e85]: Magic Pact
          - generic [ref=f2e86]: Visited
        - button "Magic Pact · stage 2, option 1 · Visited" [disabled] [ref=f2e88]:
          - generic [aria-hidden] [ref=f2e91]: ✓
          - strong [ref=f2e92]: Magic Pact
          - generic [ref=f2e93]: Visited
        - button "Loot Chest · stage 2, option 2 · Locked" [ref=f2e95] [cursor=pointer]:
          - strong [ref=f2e98]: Loot Chest
          - generic [ref=f2e99]: Locked
        - button "Magic Pact · stage 3, option 1 · Visited" [disabled] [ref=f2e101]:
          - generic [aria-hidden] [ref=f2e104]: ✓
          - strong [ref=f2e105]: Magic Pact
          - generic [ref=f2e106]: Visited
        - button "Arcane Duel · stage 3, option 2 · Locked" [ref=f2e108] [cursor=pointer]:
          - strong [ref=f2e111]: Arcane Duel
          - generic [ref=f2e112]: Locked
        - button "Arcane Duel · stage 3, option 3 · Locked" [ref=f2e114] [cursor=pointer]:
          - strong [ref=f2e117]: Arcane Duel
          - generic [ref=f2e118]: Locked
        - button "Encounter · stage 4, option 1 · Visited" [disabled] [ref=f2e120]:
          - generic [aria-hidden] [ref=f2e123]: ✓
          - strong [ref=f2e124]: Encounter
          - generic [ref=f2e125]: Visited
        - button "Arcane Duel · stage 4, option 2 · Locked" [ref=f2e127] [cursor=pointer]:
          - generic: Fire · burn
          - strong [ref=f2e130]: Arcane Duel
          - generic [ref=f2e131]: Locked
        - button "Loot Chest · stage 4, option 3 · Locked" [ref=f2e133] [cursor=pointer]:
          - strong [ref=f2e136]: Loot Chest
          - generic [ref=f2e137]: Locked
        - button "Alchemy Refuge · stage 5, option 1 · Visited" [disabled] [ref=f2e139]:
          - generic [aria-hidden] [ref=f2e142]: ✓
          - strong [ref=f2e143]: Alchemy Refuge
          - generic [ref=f2e144]: Visited
        - button "Alchemy Refuge · stage 5, option 2 · Locked" [ref=f2e146] [cursor=pointer]:
          - strong [ref=f2e149]: Alchemy Refuge
          - generic [ref=f2e150]: Locked
        - button "Loot Chest · stage 5, option 3 · Locked" [ref=f2e152] [cursor=pointer]:
          - strong [ref=f2e155]: Loot Chest
          - generic [ref=f2e156]: Locked
        - button "Encounter · stage 6, option 1 · Visited" [disabled] [ref=f2e158]:
          - generic [aria-hidden] [ref=f2e161]: ✓
          - strong [ref=f2e162]: Encounter
          - generic [ref=f2e163]: Visited
        - button "Arcane Duel · stage 6, option 2 · Locked" [ref=f2e165] [cursor=pointer]:
          - generic: Vanguard · initiative
          - strong [ref=f2e168]: Arcane Duel
          - generic [ref=f2e169]: Locked
        - button "Alchemy Refuge · stage 6, option 3 · Locked" [ref=f2e171] [cursor=pointer]:
          - strong [ref=f2e174]: Alchemy Refuge
          - generic [ref=f2e175]: Locked
        - button "Zone Boss · stage 7, option 1 · Available" [ref=f2e177] [cursor=pointer]:
          - generic [aria-hidden] [ref=f2e180]: ▴
          - strong [ref=f2e181]: Zone Boss
          - generic [ref=f2e182]: Available
          - generic [ref=f2e183]: Combat · 5 Essence
      - dialog "Node confirmation" [ref=f2e184]:
        - button "Settings" [ref=f2e185] [cursor=pointer]
        - heading "Zone Boss" [level=3] [ref=f2e188]
        - paragraph [ref=f2e189]: Uses 5 Essence. Automatic combat with your current team.
        - generic [ref=f2e190]:
          - region "Circe" [ref=f2e191]:
            - generic [ref=f2e192]:
              - generic [ref=f2e193]:
                - heading "Circe" [level=4] [ref=f2e194]
                - generic [ref=f2e195]: Fire
                - generic [ref=f2e196]: 3 · Opponents
              - generic "Opponents" [ref=f2e197]:
                - generic [ref=f2e202]:
                  - generic [ref=f2e203]: Opponent
                  - generic [ref=f2e204]: Neutral
                - generic [ref=f2e207]:
                  - generic [ref=f2e208]: Opponent
                  - generic [ref=f2e209]: Neutral
            - group [ref=f2e210]:
              - generic "Inspect opponents" [ref=f2e211] [cursor=pointer]
          - generic "Loot on victory; fixed contents in chests" [ref=f2e214]:
            - generic "Crowns" [ref=f2e215]:
              - strong [ref=f2e217]: "50"
            - generic "Gold Keys" [ref=f2e218]:
              - strong [ref=f2e220]: "1"
            - strong [ref=f2e223]: "1"
            - generic [ref=f2e224]: 50 Crowns, 1 keys, 1 toads, 0 beans.
        - generic [ref=f2e225]:
          - region "Your team" [ref=f2e226]:
            - heading "Your team" [level=4] [ref=f2e227]
            - generic [ref=f2e228]:
              - 'button "Prepare Alchemy Apprentice, position 1. Owned copy. HP 100/100, MP 40/40. Equipment: Birch wand · No core · +2 · ×1, Cadet Zephyr." [disabled] [ref=f2e229]':
                - generic [aria-hidden] [ref=f2e232]: "1"
                - generic [aria-hidden] [ref=f2e234]: Alchemy Apprentice
                - generic [aria-hidden] [ref=f2e235]:
                  - generic [ref=f2e236]: HP 100/100
                  - generic [ref=f2e237]: MP 40/40
              - button "Prepare Rune Weaver, position 2. This expedition only. HP 80/80, MP 40/40." [disabled] [ref=f2e243]:
                - generic [aria-hidden] [ref=f2e246]: "2"
                - generic [aria-hidden] [ref=f2e248]: Rune Weaver
                - generic [aria-hidden] [ref=f2e249]:
                  - generic [ref=f2e250]: HP 80/80
                  - generic [ref=f2e251]: MP 40/40
              - button "Prepare Nicolas Flamel, position 3. This expedition only. HP 95/95, MP 40/40." [disabled] [ref=f2e252]:
                - generic [aria-hidden] [ref=f2e255]: "3"
                - generic [aria-hidden] [ref=f2e257]: Nicolas Flamel
                - generic [aria-hidden] [ref=f2e258]:
                  - generic [ref=f2e259]: HP 95/95
                  - generic [ref=f2e260]: MP 40/40
              - button "Prepare Rune Weaver, position 4. This expedition only. HP 80/80, MP 40/40." [disabled] [ref=f2e261]:
                - generic [aria-hidden] [ref=f2e264]: "4"
                - generic [aria-hidden] [ref=f2e266]: Rune Weaver
                - generic [aria-hidden] [ref=f2e267]:
                  - generic [ref=f2e268]: HP 80/80
                  - generic [ref=f2e269]: MP 40/40
            - button "Prepare team" [disabled] [ref=f2e270]
            - group [ref=f2e272]:
              - generic "Team synergies" [ref=f2e273] [cursor=pointer]:
                - generic [ref=f2e275]:
                  - text: Alchemy
                  - strong [ref=f2e276]: III
          - group [ref=f2e277]:
            - 'generic "Prepare beans. Stock: 0." [ref=f2e278] [cursor=pointer]':
              - generic [ref=f2e280]:
                - generic [ref=f2e281]: Chance Beans
                - strong [aria-hidden] [ref=f2e282]: ×0
              - text: ⌄
        - generic [ref=f2e283]:
          - alert [ref=f2e284]: There is not enough Runic Essence. Refresh the reading and wait for regeneration before confirming another duel.
          - button "Check again" [ref=f2e286] [cursor=pointer]
        - generic [ref=f2e287]:
          - button "Challenge the boss" [disabled] [ref=f2e288]:
            - generic "Uses 5 Essence. Automatic combat with your current team." [ref=f2e291]:
              - strong [ref=f2e293]: "5"
          - button "Close" [ref=f2e294] [cursor=pointer]:
            - generic [aria-hidden] [ref=f2e295]: ×
  - navigation "Main navigation" [ref=f2e296]:
    - button "Map" [ref=f2e297] [cursor=pointer]
    - button "Chromodex" [ref=f2e300] [cursor=pointer]
    - button "Bazaar" [ref=f2e303] [cursor=pointer]
    - button "Missions" [ref=f2e306] [cursor=pointer]
```

# Test source

```ts
  1   | import { text } from '../../src/arcana/presentation/translations';
  2   | import { startExpedition } from './game-fixture';
  3   | import { changeLanguage } from './game-fixture';
  4   | import { pathTo, confirmEvent, readGame } from './route-helpers';
  5   | import { test, expect } from './game-fixture';
  6   | for (const language of ['es', 'en'] as const)
  7   |   test(`authority HUD and boss result survives reload in ${language}`, async ({ page }) => {
  8   |     const en = language === 'en';
  9   |     const button = (es: string, english: string) =>
  10  |       page.getByRole('button', { name: en ? english : es, exact: true });
  11  |     await page.goto('/');
  12  |     if (en) await changeLanguage(page, 'en');
  13  |     await button('Comenzar ensayo local', 'Start local trial').click();
  14  |     const energy = page.getByRole('meter', {
  15  |       name: en ? 'Runic Essence' : 'Esencia Rúnica',
  16  |       exact: true,
  17  |     });
  18  |     await expect(energy).toHaveAttribute('value', '50');
  19  |     await startExpedition(page, language);
  20  |     await expect(page.locator('.branch-map')).toBeVisible();
  21  |     // This checks a saved victory receipt; choose the complete surviving path before branching.
  22  |     // Optimizing only to an intermediate encounter can strand this fixture before the boss.
  23  |     const path = await pathTo(page, 'boss');
  24  |     for (const id of path) {
  25  |       const kind = (await readGame(page)).exploration!.run!.graph.nodes.find(
  26  |         (n) => n.id === id,
  27  |       )!.kind;
  28  |       await page.locator(`[data-node="${id}"]`).click();
  29  |       const before =
  30  |         kind === 'encounter' ? (await (await page.request.get('/api/state')).json()).state : null;
  31  |       if (kind === 'encounter') {
  32  |         if (await page.locator('[data-encounter-offer]').count()) {
  33  |           await expect(
  34  |             page.locator('[data-encounter-choice]:not([data-encounter-choice="pass"])'),
  35  |           ).toHaveCount(2);
  36  |           await expect(page.locator('.node-confirm-action')).toBeDisabled();
  37  |         } else {
  38  |           await page.locator('.node-help summary').click();
  39  |           await expect(page.getByRole('dialog')).toContainText(
  40  |             en ? 'This encounter may grant loot' : 'Este encuentro puede entregar botín',
  41  |           );
  42  |         }
  43  |         await button('Cancelar', 'Cancel').click();
  44  |         expect((await (await page.request.get('/api/state')).json()).state).toEqual(before);
  45  |         await page.locator(`[data-node="${id}"]`).click();
  46  |       }
  47  |       if (kind === 'boss') {
  48  |         const beforeRejection = (await (await page.request.get('/api/state')).json()).state;
  49  |         const reject = async (route: import('@playwright/test').Route) =>
  50  |           route.fulfill({
  51  |             status: 409,
  52  |             contentType: 'application/json',
  53  |             body: JSON.stringify({
  54  |               error: { code: 'INSUFFICIENT_ESSENCE', recoverWithSameKey: false },
  55  |             }),
  56  |           });
  57  |         await page.route('**/api/nodes/advance', reject);
  58  |         await page.locator('.node-confirm-action').click();
  59  |         await expect(page.getByRole('dialog').getByRole('alert')).toContainText(
  60  |           en ? 'There is not enough Runic Essence.' : 'No hay suficiente Esencia Rúnica.',
  61  |         );
  62  |         expect((await (await page.request.get('/api/state')).json()).state).toEqual(
  63  |           beforeRejection,
  64  |         );
  65  |         await page.unroute('**/api/nodes/advance', reject);
  66  |         await page
  67  |           .getByRole('dialog')
  68  |           .getByRole('button', { name: en ? 'Refresh state' : 'Actualizar estado', exact: true })
> 69  |           .click();
      |            ^ Error: locator.click: Test timeout of 30000ms exceeded.
  70  |         await expect(page.getByRole('dialog')).toHaveCount(0);
  71  |         await page.locator(`[data-node="${id}"]`).click();
  72  |       }
  73  |       await confirmEvent(page, language);
  74  |       if (
  75  |         kind === 'encounter' &&
  76  |         (await readGame(page)).receipts.at(-1)?.kind === 'advance-node' &&
  77  |         !(
  78  |           (await readGame(page)).receipts.at(
  79  |             -1,
  80  |           ) as import('../../src/arcana/application/run-contracts').NodeReceipt
  81  |         ).encounter
  82  |       ) {
  83  |         const saved = await readGame(page);
  84  |         await page.locator('.receipt-disclosure > summary').click();
  85  |         await expect(page.locator('.receipt-body')).toContainText(text(language, 'nodePassed'));
  86  |         await page.reload();
  87  |         await expect(page.locator('.branch-map')).toBeVisible();
  88  |         expect(await readGame(page)).toEqual(saved);
  89  |         await changeLanguage(page, en ? 'es' : 'en');
  90  |         expect(await readGame(page)).toEqual(saved);
  91  |         await changeLanguage(page, language);
  92  |       } else if (kind === 'encounter') {
  93  |         await page.locator('.receipt-disclosure > summary').click();
  94  |         const region = page.getByRole('region', {
  95  |           name: en ? 'Encounter outcome' : 'Resultado del encuentro',
  96  |           exact: true,
  97  |         });
  98  |         await expect(region).toBeVisible();
  99  |         const after = (await (await page.request.get('/api/state')).json()).state;
  100 |         const receipt = after.receipts.find(
  101 |           (r: { request?: { nodeId?: string } }) => r.request?.nodeId === id,
  102 |         );
  103 |         const resolution = receipt.encounter.resolution;
  104 |         await expect(region).toContainText(resolution.narrative.text[language]);
  105 |         await expect(region).toHaveAttribute('data-encounter-effect', resolution.effect.kind);
  106 |         expect(after.inventory.essence.points).toBe(before?.inventory.essence.points ?? 50);
  107 |         await page.reload();
  108 |         await page.locator('.receipt-disclosure > summary').click();
  109 |         await expect(region).toContainText(resolution.narrative.text[language]);
  110 |         await changeLanguage(page, en ? 'es' : 'en');
  111 |         await expect(
  112 |           page.getByRole('region', {
  113 |             name: en ? 'Resultado del encuentro' : 'Encounter outcome',
  114 |             exact: true,
  115 |           }),
  116 |         ).toContainText(resolution.narrative.text[en ? 'es' : 'en']);
  117 |         await changeLanguage(page, language);
  118 |         expect((await (await page.request.get('/api/state')).json()).state).toEqual(after);
  119 |         await button('Volver a la ruta', 'Return to route').click();
  120 |       }
  121 |       if (id === 'pasaje:0:0') {
  122 |         await expect(
  123 |           page.getByRole('region', {
  124 |             name: en ? 'Confirmed node result' : 'Resultado de nodo confirmado',
  125 |             exact: true,
  126 |           }),
  127 |         ).toContainText(en ? 'Magic Pact' : 'Pacto Mágico');
  128 |         await expect
  129 |           .poll(async () =>
  130 |             page.locator('.node-result').evaluate((region) => {
  131 |               const bounds = region.getBoundingClientRect(),
  132 |                 nav = document.querySelector('nav')!.getBoundingClientRect();
  133 |               return bounds.top >= 0 && bounds.bottom <= nav.top;
  134 |             }),
  135 |           )
  136 |           .toBe(true);
  137 |       }
  138 |       if (kind === 'duel') await button('Volver al mapa', 'Back to map').click();
  139 |     }
  140 |     await expect(
  141 |       page.getByRole('heading', { name: en ? 'Combat Arena' : 'Arena de Combate', exact: true }),
  142 |     ).toBeVisible();
  143 |     await button('Volver al mapa', 'Back to map').click();
  144 |     await page.locator('.closure-history > summary').click();
  145 |     await page.locator('.receipt-disclosure > summary').click();
  146 |     const result = page.getByRole('region', {
  147 |       name: en ? 'Confirmed node result' : 'Resultado de nodo confirmado',
  148 |       exact: true,
  149 |     });
  150 |     await expect(result).toContainText(en ? '50 Crowns' : '50 Coronas');
  151 |     await expect(result).toContainText(en ? '1 Gold Key' : '1 Llave de Oro');
  152 |     await expect(result).toContainText(
  153 |       en
  154 |         ? 'The next location unlock is saved.'
  155 |         : 'El desbloqueo de la siguiente localización está guardado.',
  156 |     );
  157 |     const resolved = await readGame(page);
  158 |     const combatCount = resolved.receipts.filter(
  159 |       (r) => r.kind === 'advance-node' && r.battle,
  160 |     ).length;
  161 |     await expect(energy).toHaveAttribute('value', String(50 - combatCount * 5));
  162 |     const read = async () => (await (await page.request.get('/api/state')).json()).state;
  163 |     const before = await read();
  164 |     await button('Actualizar Esencia', 'Refresh Essence').click();
  165 |     expect(await read()).toEqual(before);
  166 |     await page.reload();
  167 |     await page.locator('.closure-history > summary').click();
  168 |     await expect(result).toContainText(en ? 'Zone Boss' : 'Jefe de Zona');
  169 |     await page.locator('.receipt-disclosure > summary').click();
```