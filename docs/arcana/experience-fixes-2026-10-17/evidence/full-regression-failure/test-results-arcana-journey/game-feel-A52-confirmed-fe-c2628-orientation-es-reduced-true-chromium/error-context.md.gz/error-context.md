# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: game-feel.spec.ts >> A52 confirmed feedback and orientation es reduced=true
- Location: tests/browser-trial/game-feel.spec.ts:9:5

# Error details

```
Test timeout of 30000ms exceeded.
```

```
Error: locator.click: Test timeout of 30000ms exceeded.
Call log:
  - waiting for getByRole('button', { name: 'Actualizar estado', exact: true })

```

# Page snapshot

```yaml
- generic [ref=e3]:
  - link "Saltar al contenido" [ref=e4] [cursor=pointer]:
    - /url: "#content"
  - banner [ref=e5]:
    - heading "ARCANA" [level=1] [ref=e6]
    - generic [ref=e7]:
      - status [ref=e8]
      - button "Una noche encantada" [ref=e9] [cursor=pointer]
    - button "Ajustes" [ref=e12] [cursor=pointer]
  - status [ref=e15]: Nodo 2 resuelto. El resultado está confirmado y guardado.
  - generic [ref=e16]:
    - strong [ref=e17]:
      - generic "Coronas" [ref=e19]: "50"
    - generic [ref=e20]:
      - generic [ref=e21]:
        - generic [ref=e23]: Esencia
        - text: 50 / 50
        - meter "Esencia Rúnica" [ref=e24]
      - generic [ref=e25]: Esencia al máximo.
      - button "Actualizar Esencia" [disabled] [ref=e26]
    - generic [ref=e29]:
      - strong [aria-hidden] [ref=e31]: "0"
      - generic [ref=e32]: 0 Llaves de Oro
  - main [ref=e33]:
    - status [ref=e34]
    - generic [ref=e35]:
      - alert [ref=e36]: No hay suficientes Coronas Mágicas para esta compra. Actualiza el saldo antes de volver a confirmar.
      - button "Volver a consultar" [ref=e38] [cursor=pointer]
    - region "La Confitería Encantada" [ref=e40]:
      - generic [ref=e41]:
        - button "Volver al callejón" [ref=e42] [cursor=pointer]:
          - generic [ref=e48]: Callejón
        - heading "La Confitería Encantada" [level=2] [ref=e49]
      - group "Elige un dulce" [ref=e50]:
        - button "Sapo de Cacao" [ref=e52] [cursor=pointer]:
          - generic [ref=e55]: "10"
        - generic [ref=e58]:
          - button "Grageas del Azar" [pressed] [ref=e59] [cursor=pointer]:
            - generic [ref=e62]: "5"
          - button "Cómo usar tus grageas" [ref=e65] [cursor=pointer]:
            - generic [aria-hidden] [ref=e66]: i
            - generic [ref=e67]: Información
      - button "Comprar Grageas del Azar · 5 Coronas" [disabled] [ref=e69]:
        - generic [ref=e71]:
          - strong [ref=e72]: Comprar
          - generic [ref=e73]: "5"
        - generic [aria-hidden] [ref=e74]: ↗
  - navigation "Navegación principal" [ref=e75]:
    - button "Mapa" [ref=e76] [cursor=pointer]
    - button "Cromodex" [ref=e79] [cursor=pointer]
    - button "Bazar" [ref=e82] [cursor=pointer]
    - button "Misiones" [ref=e85] [cursor=pointer]
```

# Test source

```ts
  1   | import { startExpedition } from './game-fixture';
  2   | import { openAlbumFilters } from './game-fixture';
  3   | import { confirmEvent } from './route-helpers';
  4   | import { changeLanguage } from './game-fixture';
  5   | import { expect, test } from './game-fixture';
  6   | 
  7   | for (const language of ['es', 'en'] as const) {
  8   |   for (const reduced of [false, true]) {
  9   |     test(`A52 confirmed feedback and orientation ${language} reduced=${reduced}`, async ({
  10  |       page,
  11  |     }) => {
  12  |       await page.emulateMedia({ reducedMotion: reduced ? 'reduce' : 'no-preference' });
  13  |       await page.goto('/');
  14  |       if (language === 'en') await changeLanguage(page, 'en');
  15  |       await page
  16  |         .getByRole('button', {
  17  |           name: language === 'es' ? 'Comenzar ensayo local' : 'Start local trial',
  18  |           exact: true,
  19  |         })
  20  |         .click();
  21  |       const guide = page.locator('[data-expedition-cue]');
  22  |       await expect(guide).toHaveAttribute('data-expedition-cue', 'begin');
  23  |       await startExpedition(page, language);
  24  |       await expect(guide).toHaveAttribute('data-expedition-cue', 'recruit');
  25  |       for (const id of ['pasaje:0:0', 'pasaje:1:0']) {
  26  |         await page.locator(`[data-node="${id}"]`).click();
  27  |         await confirmEvent(page, language);
  28  |       }
  29  |       await expect(guide).toHaveAttribute('data-expedition-cue', 'choose');
  30  |       await expect(page.locator('.team-unit')).toHaveCount(3);
  31  |       await expect(
  32  |         page
  33  |           .locator('.team-source')
  34  |           .filter({ hasText: language === 'es' ? 'Aliado temporal' : 'Temporary ally' }),
  35  |       ).toHaveCount(2);
  36  |       // Both the canvas and DOM share the route; guidance/filter/language never send a command.
  37  |       await expect(page.locator('.map-scroll canvas')).toBeVisible();
  38  |       const state = async () => (await (await page.request.get('/api/state')).json()).state;
  39  |       const before = await state();
  40  |       await page
  41  |         .getByRole('button', { name: language === 'es' ? 'Cromodex' : 'Chromodex', exact: true })
  42  |         .click();
  43  |       await expect(
  44  |         page.getByText(
  45  |           language === 'es'
  46  |             ? 'Identidades descubiertas: 1 de 30'
  47  |             : 'Identities discovered: 1 of 30',
  48  |         ),
  49  |       ).toBeVisible();
  50  |       await expect(page.locator('.card-team-state')).toHaveCount(1);
  51  |       await openAlbumFilters(page);
  52  |       await page
  53  |         .getByRole('group', {
  54  |           name: language === 'es' ? 'Filtro de descubrimiento' : 'Discovery filter',
  55  |           exact: false,
  56  |         })
  57  |         .locator('[data-visual-value="discovered"]')
  58  |         .click();
  59  |       await expect(page.locator('.album .card')).toHaveCount(1);
  60  |       await changeLanguage(page, language === 'es' ? 'en' : 'es');
  61  |       expect(await state()).toEqual(before);
  62  |       await changeLanguage(page, language);
  63  |       await page
  64  |         .getByRole('button', { name: language === 'es' ? 'Bazar' : 'Bazaar', exact: true })
  65  |         .click();
  66  |       await page.locator('[data-shop="confectionery"]').click();
  67  |       await page
  68  |         .getByRole('button', {
  69  |           name: language === 'es' ? 'Grageas del Azar' : 'Chance Beans',
  70  |           exact: true,
  71  |         })
  72  |         .click();
  73  |       const purchase = page.getByRole('button', {
  74  |         name:
  75  |           language === 'es'
  76  |             ? 'Comprar Grageas del Azar · 5 Coronas'
  77  |             : 'Buy Chance Beans · 5 Crowns',
  78  |         exact: true,
  79  |       });
  80  |       await page.route('**/api/purchases', (route) =>
  81  |         route.fulfill({
  82  |           status: 422,
  83  |           contentType: 'application/json',
  84  |           body: JSON.stringify({
  85  |             error: { code: 'INSUFFICIENT_CROWNS', recoverWithSameKey: false },
  86  |           }),
  87  |         }),
  88  |       );
  89  |       // A rejected command cannot generate an optimistic success banner.
  90  |       await purchase.click();
  91  |       await expect(page.locator('.operation-feedback')).toBeHidden();
  92  |       await expect(page.getByRole('alert')).toBeVisible();
  93  |       expect(await state()).toEqual(before);
  94  |       await page.unroute('**/api/purchases');
  95  |       await page
  96  |         .getByRole('button', {
  97  |           name: language === 'es' ? 'Actualizar estado' : 'Refresh state',
  98  |           exact: true,
  99  |         })
> 100 |         .click();
      |          ^ Error: locator.click: Test timeout of 30000ms exceeded.
  101 |       // Refresh remounts the product display; choose the beans again without spending.
  102 |       await page
  103 |         .getByRole('button', {
  104 |           name: language === 'es' ? 'Grageas del Azar' : 'Chance Beans',
  105 |           exact: true,
  106 |         })
  107 |         .click();
  108 |       await expect(purchase).toBeEnabled();
  109 |       await purchase.click();
  110 |       await expect(page.locator('.operation-feedback')).toBeVisible();
  111 |       const afterPurchase = await state();
  112 |       const receipt = afterPurchase.receipts.find((r: { kind: string }) => r.kind === 'purchase');
  113 |       expect(receipt).toBeTruthy();
  114 |       await expect(page.locator('.operation-feedback')).toHaveAttribute(
  115 |         'data-confirmed-operation',
  116 |         receipt.id,
  117 |       );
  118 |       const announcement = await page.locator('main > [role="status"]').textContent();
  119 |       if (reduced)
  120 |         expect(
  121 |           await page.locator('.operation-feedback').evaluate((el) => el.getAnimations().length),
  122 |         ).toBe(0);
  123 |       await changeLanguage(page, language === 'es' ? 'en' : 'es');
  124 |       expect(await page.locator('main > [role="status"]').textContent()).toBe(announcement);
  125 |       expect(await state()).toEqual(afterPurchase);
  126 |       await page.setViewportSize({ width: 320, height: 844 });
  127 |       await page.evaluate(() => {
  128 |         document.documentElement.style.fontSize = '200%';
  129 |       });
  130 |       expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(
  131 |         true,
  132 |       );
  133 |       await page.reload();
  134 |       expect(await state()).toEqual(afterPurchase);
  135 |     });
  136 |   }
  137 | }
  138 | 
```