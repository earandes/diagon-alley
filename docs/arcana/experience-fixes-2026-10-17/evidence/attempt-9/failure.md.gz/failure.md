# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: supplies-a75.spec.ts >> A75 bought jar remains stock until explicit duel commit es/diagon-alley
- Location: tests/browser-experience-fixes/supplies-a75.spec.ts:11:5

# Error details

```
Error: expect(received).toHaveLength(expected)

Expected length: 0
Received length: 1
Received array:  [{"id": "f9e8b4fa-2201-45bc-8a89-658b0fc03de3:loot:0", "kind": "random-beans", "status": "available"}]
```

# Page snapshot

```yaml
- generic [ref=e3]:
  - link "Saltar al contenido" [ref=e4] [cursor=pointer]:
    - /url: "#content"
  - banner [ref=e5]:
    - heading "DIAGON ALLEY" [level=1] [ref=e6]
    - button "Ajustes" [ref=e7] [cursor=pointer]
  - status [ref=e10]: Nodo 4 resuelto. El resultado está confirmado y guardado.
  - group [ref=e11]:
    - generic "Recursos guardados" [ref=e12] [cursor=pointer]
  - main [active] [ref=e15]:
    - status [ref=e16]: "Compra guardada: 1 tarro de Grageas · −5 Galeones. Asígnalo antes de un duelo."
    - generic [ref=e17]:
      - generic [ref=e18]:
        - button "Volver al mapa" [ref=e19] [cursor=pointer]: ←
        - heading "Arena de Combate" [level=2] [ref=e20]
        - generic [ref=e21]: Ronda 0
      - generic [ref=e22]:
        - group "Reproducción del combate" [ref=e23]:
          - button "Pausa" [ref=e24] [cursor=pointer]: Ⅱ Pausa
          - button "Auto" [pressed] [ref=e25] [cursor=pointer]: ▷ Auto
          - button "2x" [ref=e26] [cursor=pointer]
          - button "Omitir reproducción" [ref=e27] [cursor=pointer]: ▸▸|
        - button "Registro del combate" [ref=e29] [cursor=pointer]
      - generic [ref=e33]:
        - region "Tu Equipo" [ref=e34]:
          - heading "Tu Equipo" [level=3] [ref=e35]
          - generic [ref=e36]:
            - article "Tu Equipo · Unidad 1 · Harry Potter" [ref=e37]:
              - 'button "Inspeccionar: Tu Equipo · Unidad 1 · Harry Potter" [ref=e38] [cursor=pointer]':
                - strong [ref=e41]: Harry Potter
                - generic [aria-hidden] [ref=e42]: "1"
                - generic [ref=e43]:
                  - meter "Vida de Tu Equipo · Unidad 1 · Harry Potter" [ref=e44]
                  - generic [ref=e45]:
                    - text: "100"
                    - generic [ref=e46]: / 100 PV
            - article "Tu Equipo · Unidad 2 · Ginny Weasley" [ref=e47]:
              - 'button "Inspeccionar: Tu Equipo · Unidad 2 · Ginny Weasley" [ref=e48] [cursor=pointer]':
                - strong [ref=e51]: Ginny Weasley
                - generic [aria-hidden] [ref=e52]: "2"
                - generic [ref=e53]:
                  - meter "Vida de Tu Equipo · Unidad 2 · Ginny Weasley" [ref=e54]
                  - generic [ref=e55]:
                    - text: "80"
                    - generic [ref=e56]: / 80 PV
            - article "Tu Equipo · Unidad 3 · Nicolás Flamel" [ref=e57]:
              - 'button "Inspeccionar: Tu Equipo · Unidad 3 · Nicolás Flamel" [ref=e58] [cursor=pointer]':
                - strong [ref=e61]: Nicolás Flamel
                - generic [aria-hidden] [ref=e62]: "3"
                - generic [ref=e63]:
                  - meter "Vida de Tu Equipo · Unidad 3 · Nicolás Flamel" [ref=e64]
                  - generic [ref=e65]:
                    - text: "95"
                    - generic [ref=e66]: / 95 PV
            - article "Tu Equipo · Unidad 4 · Ginny Weasley" [ref=e67]:
              - 'button "Inspeccionar: Tu Equipo · Unidad 4 · Ginny Weasley" [ref=e68] [cursor=pointer]':
                - strong [ref=e71]: Ginny Weasley
                - generic [aria-hidden] [ref=e72]: "4"
                - generic [ref=e73]:
                  - meter "Vida de Tu Equipo · Unidad 4 · Ginny Weasley" [ref=e74]
                  - generic [ref=e75]:
                    - text: "80"
                    - generic [ref=e76]: / 80 PV
          - paragraph [ref=e77]
        - region "Rival" [ref=e78]:
          - heading "Rival" [level=3] [ref=e79]
          - generic [ref=e80]:
            - article "Rival · Unidad 1 · Nymphadora Tonks" [ref=e81]:
              - 'button "Inspeccionar: Rival · Unidad 1 · Nymphadora Tonks" [ref=e82] [cursor=pointer]':
                - strong [ref=e85]: Nymphadora Tonks
                - generic [aria-hidden] [ref=e86]: "1"
                - generic [ref=e87]:
                  - meter "Vida de Rival · Unidad 1 · Nymphadora Tonks" [ref=e88]
                  - generic [ref=e89]:
                    - text: "85"
                    - generic [ref=e90]: / 85 PV
            - article "Rival · Unidad 2 · Ginny Weasley" [ref=e91]:
              - 'button "Inspeccionar: Rival · Unidad 2 · Ginny Weasley" [ref=e92] [cursor=pointer]':
                - strong [ref=e95]: Ginny Weasley
                - generic [aria-hidden] [ref=e96]: "2"
                - generic [ref=e97]:
                  - meter "Vida de Rival · Unidad 2 · Ginny Weasley" [ref=e98]
                  - generic [ref=e99]:
                    - text: "80"
                    - generic [ref=e100]: / 80 PV
            - article "Rival · Unidad 3 · Rival mágico" [ref=e101]:
              - 'button "Inspeccionar: Rival · Unidad 3 · Rival mágico" [ref=e102] [cursor=pointer]':
                - strong [ref=e105]: Rival mágico
                - generic [aria-hidden] [ref=e106]: "3"
                - generic [ref=e107]:
                  - meter "Vida de Rival · Unidad 3 · Rival mágico" [ref=e108]
                  - generic [ref=e109]:
                    - text: "25"
                    - generic [ref=e110]: / 25 PV
          - paragraph [ref=e111]
      - paragraph [ref=e113]: Combate guardado
      - status [ref=e114]
```

# Test source

```ts
  54  |       expect(flavourCollection(purchased).every((entry) => !entry.discovered)).toBe(true);
  55  |       await page
  56  |         .locator('nav button')
  57  |         .filter({ has: page.locator('[data-art="ui.map"]') })
  58  |         .click();
  59  |       await startExpedition(page, language);
  60  |       const duelId = await reachNode(page, 'duel', language);
  61  |       const before = await readGame(page);
  62  |       expect(
  63  |         before.exploration!.run!.members.filter((member) => member.source === 'temporary').length,
  64  |       ).toBeGreaterThanOrEqual(2);
  65  |       const stock = before.inventory.products.filter(
  66  |         (product) => product.kind === 'random-beans' && product.status === 'available',
  67  |       ).length;
  68  |       const jar = before.inventory.products.find((product) => product.id === purchasedJar.id)!;
  69  |       expect(jar.status).toBe('available');
  70  |       const carrier = before.exploration!.run!.members[0].unit.id;
  71  |       const alternate = before.exploration!.run!.members[1].unit.id;
  72  |       await page.locator(`[data-node="${duelId}"]`).click();
  73  |       const summary = page.locator('.node-event-dialog .boss-supplies > summary');
  74  |       await expect(summary).toHaveAttribute('data-bean-stock', String(stock));
  75  |       await expect(summary).toHaveAttribute('data-bean-draft', '0');
  76  |       await expect(summary).not.toContainText('/');
  77  |       await summary.click();
  78  |       await page.locator(`[data-bean-id="${jar.id}"]`).click();
  79  |       await page.locator(`[data-bean-unit="${carrier}"]`).click();
  80  |       await expect(summary).toHaveAttribute('data-bean-draft', '1');
  81  |       await expect(summary).toHaveAttribute('data-bean-stock', String(stock));
  82  |       await page.locator(`[data-bean-unit="${alternate}"]`).click();
  83  |       await expect(page.locator(`[data-bean-unit="${carrier}"]`)).toHaveAttribute(
  84  |         'aria-pressed',
  85  |         'false',
  86  |       );
  87  |       await expect(page.locator(`[data-bean-unit="${alternate}"]`)).toHaveAttribute(
  88  |         'aria-pressed',
  89  |         'true',
  90  |       );
  91  |       await page.locator(`[data-bean-unit="${alternate}"]`).click();
  92  |       await expect(summary).toHaveAttribute('data-bean-draft', '0');
  93  |       await page.locator(`[data-bean-unit="${carrier}"]`).click();
  94  |       expect(await readGame(page)).toEqual(before);
  95  |       expect(flavourCollection(await readGame(page)).every((entry) => !entry.discovered)).toBe(
  96  |         true,
  97  |       );
  98  |       await page
  99  |         .locator('.node-event-dialog')
  100 |         .getByRole('button', { name: language === 'es' ? 'Cancelar' : 'Cancel', exact: true })
  101 |         .click();
  102 |       expect(await readGame(page)).toEqual(before);
  103 |       await page.locator(`[data-node="${duelId}"]`).click();
  104 |       await expect(summary).toHaveAttribute('data-bean-draft', '0');
  105 |       await expect(summary).toHaveAttribute('data-bean-stock', String(stock));
  106 |       await summary.click();
  107 |       await page.locator(`[data-bean-id="${jar.id}"]`).click();
  108 |       await page.locator(`[data-bean-unit="${carrier}"]`).click();
  109 |       let advancePosts = 0;
  110 |       page.on('request', (request) => {
  111 |         if (request.method() === 'POST' && request.url().endsWith('/nodes/advance')) advancePosts++;
  112 |       });
  113 |       if (language === 'es' && pack === 'diagon-alley') {
  114 |         // Adverse transport only: the unmodified server commits and its response is lost.
  115 |         await page.route('**/api/nodes/advance', async (route) => {
  116 |           const response = await route.fetch();
  117 |           expect(response.ok()).toBe(true);
  118 |           await route.abort('failed');
  119 |         });
  120 |         await page.locator('.node-confirm-action').click();
  121 |         await expect(page.locator('.node-event-dialog [data-recovery-notice]')).toBeVisible();
  122 |         await expect(
  123 |           page.locator('.node-event-dialog').getByRole('button', {
  124 |             name: 'Recuperar operación',
  125 |             exact: true,
  126 |           }),
  127 |         ).toBeEnabled();
  128 |         const committed = await readGame(page);
  129 |         expect(committed.inventory.products.find((p) => p.id === jar.id)?.status).toBe('consumed');
  130 |         await page
  131 |           .locator('.node-event-dialog')
  132 |           .getByRole('button', { name: 'Recuperar operación', exact: true })
  133 |           .click();
  134 |         await expect(page.locator('.node-event-dialog')).toHaveCount(0);
  135 |       } else {
  136 |         await confirmEvent(page, language);
  137 |       }
  138 |       await expect(page.locator('.battle-panel')).toBeVisible();
  139 |       const after = await readGame(page);
  140 |       const receipt = [...after.receipts]
  141 |         .reverse()
  142 |         .find((candidate) => candidate.kind === 'advance-node');
  143 |       if (receipt?.kind !== 'advance-node' || !receipt.battle)
  144 |         throw Error('Missing confirmed duel receipt');
  145 |       expect(receipt.request.assignments).toEqual([{ unitId: carrier, beanId: jar.id }]);
  146 |       expect(after.inventory.products.find((p) => p.id === jar.id)).toMatchObject({
  147 |         status: 'consumed',
  148 |         operationId: receipt.id,
  149 |       });
  150 |       expect(
  151 |         after.inventory.products.filter(
  152 |           (product) => product.kind === 'random-beans' && product.status === 'available',
  153 |         ),
> 154 |       ).toHaveLength(stock - 1);
      |         ^ Error: expect(received).toHaveLength(expected)
  155 |       expect(after.inventory.essence.points).toBe(before.inventory.essence.points - 5);
  156 |       expect(after.receipts.filter((candidate) => candidate.id === receipt.id)).toHaveLength(1);
  157 |       const activations = receipt.battle.events.filter(
  158 |         (event) => event.kind === 'bean-activated' && event.unitId === jar.id,
  159 |       );
  160 |       expect(activations).toHaveLength(1);
  161 |       if (activations[0].kind !== 'bean-activated') throw Error('Missing activation');
  162 |       expect(activations[0].actorId).toBe(carrier);
  163 |       const discovered = flavourCollection(after).filter((entry) => entry.discovered);
  164 |       expect(discovered).toHaveLength(1);
  165 |       expect(discovered[0]).toMatchObject({
  166 |         flavour: activations[0].flavour,
  167 |         activations: 1,
  168 |         firstDiscovery: { operationId: receipt.id, beanUnitId: jar.id },
  169 |       });
  170 |       expect(advancePosts).toBe(1);
  171 |       // Reload recovers the same committed log/consumption; querying never replays an operation.
  172 |       await page.reload();
  173 |       await expect(page.locator('.battle-panel')).toBeVisible();
  174 |       expect(await readGame(page)).toEqual(after);
  175 |       expect(advancePosts).toBe(1);
  176 |       // The arena deliberately folds the navigation dock. Return through its
  177 |       // real exit before consulting the discovered flavour in the collection.
  178 |       await page.locator('.arena-exit').click();
  179 |       await expect(page.locator('.branch-map')).toBeVisible();
  180 |       await page
  181 |         .locator('nav button')
  182 |         .filter({ has: page.locator('[data-art="ui.collection"]') })
  183 |         .click();
  184 |       await expect(page.locator('.flavour-cabinet [data-discovered="true"]')).toHaveCount(1);
  185 |       await expect(
  186 |         page.locator(
  187 |           `.flavour-cabinet [data-discovered="true"] [data-art="product.bean-${activations[0].flavour}"]`,
  188 |         ),
  189 |       ).toBeVisible();
  190 |       await expect(page.locator('.flavour-cabinet [data-discovered="false"]')).toHaveCount(3);
  191 |       expect(await readGame(page)).toEqual(after);
  192 |     });
  193 |   }
  194 | }
  195 | 
```