# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: map-settings-a75.spec.ts >> A75 diagon-alley es map and list retain visible fallback when both icons fail
- Location: tests/browser-experience-fixes/map-settings-a75.spec.ts:80:5

# Error details

```
Error: expect(locator).toHaveCount(expected) failed

Locator:  locator('.map-view-toggle').locator('img')
Expected: 0
Received: 1
Timeout:  12000ms

Call log:
  - Expect "toHaveCount" locator('.map-view-toggle').locator('img') with timeout 12000ms
  - waiting for locator('.map-view-toggle').locator('img')
    28 × locator resolved to 1 element
       - unexpected value "1"

```

# Page snapshot

```yaml
- generic [ref=f1e3]:
  - link "Saltar al contenido" [ref=f1e4] [cursor=pointer]:
    - /url: "#content"
  - banner [ref=f1e5]:
    - heading "Callejón Diagón Descubrimiento" [level=1] [ref=f1e6]:
      - text: Callejón Diagón
      - generic [ref=f1e7]: Descubrimiento
    - generic [ref=f1e8]:
      - status [ref=f1e9]
      - button "Una noche encantada" [ref=f1e10] [cursor=pointer]
    - button "Ajustes" [ref=f1e13] [cursor=pointer]
  - status [ref=f1e16]
  - generic [ref=f1e17]:
    - strong [ref=f1e18]:
      - generic "Galeones" [ref=f1e20]: "50"
    - generic [ref=f1e21]:
      - generic [ref=f1e22]:
        - generic [ref=f1e24]: Energía
        - text: 50 / 50
        - meter "Energía mágica" [ref=f1e25]
      - generic [ref=f1e26]: Energía al máximo.
      - button "Actualizar Energía" [ref=f1e27] [cursor=pointer]
    - generic [ref=f1e30]:
      - strong [aria-hidden] [ref=f1e32]: "0"
      - generic [ref=f1e33]: 0 Llaves de Oro
  - main [ref=f1e34]:
    - status [ref=f1e35]
    - generic [ref=f1e36]:
      - generic:
        - complementary "Siguiente objetivo":
          - generic:
            - heading "Un aliado más en el camino" [level=3]
            - group [ref=f1e37]:
              - generic "Siguiente objetivo" [ref=f1e38] [cursor=pointer]: "?"
            - 'generic "Etapas recorridas: 0 de 7"': 0 / 7
      - region "Tu Equipo" [ref=f1e39]:
        - heading "Tu Equipo" [level=2] [ref=f1e40]
        - button "Harry Potter" [ref=f1e42] [cursor=pointer]:
          - generic [ref=f1e44]: Copia propia
          - meter "Vida de Harry Potter" [ref=f1e47]
        - button "Prepara tu expedición" [ref=f1e48] [cursor=pointer]
      - button "Ver lista de nodos" [ref=f1e51] [cursor=pointer]
      - generic [ref=f1e54]:
        - generic "Inicio"
        - button "Pacto Mágico · etapa 1, opción 1 · Disponible" [ref=f1e56] [cursor=pointer]:
          - generic [aria-hidden] [ref=f1e59]: ▴
          - strong [ref=f1e60]: Pacto Mágico
          - generic [ref=f1e61]: Disponible
          - generic [ref=f1e62]: Aliado temporal
        - button "Pacto Mágico · etapa 2, opción 1 · Bloqueado" [ref=f1e64] [cursor=pointer]:
          - strong [ref=f1e67]: Pacto Mágico
          - generic [ref=f1e68]: Bloqueado
        - button "Cofre de Botín · etapa 2, opción 2 · Bloqueado" [ref=f1e70] [cursor=pointer]:
          - strong [ref=f1e73]: Cofre de Botín
          - generic [ref=f1e74]: Bloqueado
        - button "Pacto Mágico · etapa 3, opción 1 · Bloqueado" [ref=f1e76] [cursor=pointer]:
          - strong [ref=f1e79]: Pacto Mágico
          - generic [ref=f1e80]: Bloqueado
        - button "Refugio Alquímico · etapa 3, opción 2 · Bloqueado" [ref=f1e82] [cursor=pointer]:
          - strong [ref=f1e85]: Refugio Alquímico
          - generic [ref=f1e86]: Bloqueado
        - button "Encuentro · etapa 3, opción 3 · Bloqueado" [ref=f1e88] [cursor=pointer]:
          - strong [ref=f1e91]: Encuentro
          - generic [ref=f1e92]: Bloqueado
        - button "Encuentro · etapa 4, opción 1 · Bloqueado" [ref=f1e94] [cursor=pointer]:
          - strong [ref=f1e97]: Encuentro
          - generic [ref=f1e98]: Bloqueado
        - button "Cofre de Botín · etapa 4, opción 2 · Bloqueado" [ref=f1e100] [cursor=pointer]:
          - strong [ref=f1e103]: Cofre de Botín
          - generic [ref=f1e104]: Bloqueado
        - button "Refugio Alquímico · etapa 4, opción 3 · Bloqueado" [ref=f1e106] [cursor=pointer]:
          - strong [ref=f1e109]: Refugio Alquímico
          - generic [ref=f1e110]: Bloqueado
        - button "Cofre de Botín · etapa 5, opción 1 · Bloqueado" [ref=f1e112] [cursor=pointer]:
          - strong [ref=f1e115]: Cofre de Botín
          - generic [ref=f1e116]: Bloqueado
        - button "Refugio Alquímico · etapa 5, opción 2 · Bloqueado" [ref=f1e118] [cursor=pointer]:
          - strong [ref=f1e121]: Refugio Alquímico
          - generic [ref=f1e122]: Bloqueado
        - button "Duelo mágico · etapa 5, opción 3 · Bloqueado" [ref=f1e124] [cursor=pointer]:
          - generic: Vanguardia · iniciativa
          - strong [ref=f1e127]: Duelo mágico
          - generic [ref=f1e128]: Bloqueado
        - button "Duelo mágico · etapa 6, opción 1 · Bloqueado" [ref=f1e130] [cursor=pointer]:
          - generic: Fuego · quemadura
          - strong [ref=f1e133]: Duelo mágico
          - generic [ref=f1e134]: Bloqueado
        - button "Duelo mágico · etapa 6, opción 2 · Bloqueado" [ref=f1e136] [cursor=pointer]:
          - generic: Vanguardia · iniciativa
          - strong [ref=f1e139]: Duelo mágico
          - generic [ref=f1e140]: Bloqueado
        - button "Duelo mágico · etapa 6, opción 3 · Bloqueado" [ref=f1e142] [cursor=pointer]:
          - generic: Fuego · quemadura
          - strong [ref=f1e145]: Duelo mágico
          - generic [ref=f1e146]: Bloqueado
        - button "Jefe de Zona · etapa 7, opción 1 · Bloqueado" [ref=f1e148] [cursor=pointer]:
          - strong [ref=f1e151]: Jefe de Zona
          - generic [ref=f1e152]: Bloqueado
  - navigation "Navegación principal" [ref=f1e153]:
    - button "Mapa" [ref=f1e154] [cursor=pointer]
    - button "Álbum de Cromos" [ref=f1e157] [cursor=pointer]
    - button "Callejón" [ref=f1e160] [cursor=pointer]
    - button "Misiones" [ref=f1e163] [cursor=pointer]
```

# Test source

```ts
  2   | import { mkdir, writeFile } from 'node:fs/promises';
  3   | import { resolve } from 'node:path';
  4   | import {
  5   |   test,
  6   |   expect,
  7   |   type Page,
  8   |   changeLanguage,
  9   |   startExpedition,
  10  | } from '../browser-trial/game-fixture';
  11  | import { reachNode, confirmEvent } from '../browser-trial/route-helpers';
  12  | 
  13  | test.use({ baseURL: 'http://127.0.0.1:5520', hasTouch: true });
  14  | test.beforeEach(async ({ browserName, viewport }) => {
  15  |   test.skip(
  16  |     browserName !== 'chromium' || viewport?.width !== 390,
  17  |     'A75 public-route and preference contracts use one Chromium mobile context; other suites cover rendering matrices.',
  18  |   );
  19  | });
  20  | const read = async (page: Page) => (await (await page.request.get('/api/state')).json()).state;
  21  | const settings = async (page: Page) => {
  22  |   await page.locator('.game-header > .settings-trigger').click();
  23  |   const dialog = page.locator('dialog.game-settings[open]');
  24  |   await expect(dialog).toBeVisible();
  25  |   return dialog;
  26  | };
  27  | const packPreference = async (page: Page, pack: string) =>
  28  |   page.addInitScript((value) => {
  29  |     localStorage.setItem('arcana.presentation.content-pack.v1', value);
  30  |   }, pack);
  31  | 
  32  | for (const pack of ['diagon-alley', 'arcana'])
  33  |   for (const language of ['es', 'en'] as const) {
  34  |     test(`A75 ${pack} ${language} route book distinguishes branches and consultation never advances`, async ({
  35  |       page,
  36  |     }) => {
  37  |       await packPreference(page, pack);
  38  |       await page.goto('/');
  39  |       if (language === 'en') await changeLanguage(page, language);
  40  |       await page.locator('.portal-enter').click();
  41  |       await startExpedition(page, language);
  42  |       const before = await read(page);
  43  |       let posts = 0;
  44  |       page.on('request', (request) => {
  45  |         if (request.method() === 'POST') posts++;
  46  |       });
  47  |       const future = page.locator('[data-node-state="locked"]').first();
  48  |       await expect(future).toBeEnabled();
  49  |       await future.focus();
  50  |       await page.keyboard.press('Enter');
  51  |       const inspection = page.locator('dialog.route-inspection[open]');
  52  |       await expect(inspection).toBeVisible();
  53  |       await expect(inspection).toContainText(language === 'es' ? 'Solo consulta' : 'Read only');
  54  |       await expect(inspection.locator('.node-confirm-action')).toHaveCount(0);
  55  |       if (language === 'es' && pack === 'diagon-alley') await selectedA75(page, 'route-inspection');
  56  |       await page.keyboard.press('Escape');
  57  |       await expect(inspection).toHaveCount(0);
  58  |       await expect(future).toBeFocused();
  59  |       await page.locator('.map-view-toggle').click();
  60  |       const entries = page.locator('.route-book-entry');
  61  |       expect(await entries.count()).toBe(before.exploration.run.graph.nodes.length);
  62  |       const names = await entries
  63  |         .locator('[data-node]')
  64  |         .evaluateAll((buttons) => buttons.map((button) => button.getAttribute('aria-label')));
  65  |       expect(new Set(names).size).toBe(names.length);
  66  |       const branch = entries.filter({ has: page.locator('[data-node-state="locked"]') }).first();
  67  |       await branch.locator('summary').tap();
  68  |       await expect(branch).toContainText(language === 'es' ? 'Desde' : 'From');
  69  |       await expect(branch).toContainText(language === 'es' ? 'Continúa hacia' : 'Continues to');
  70  |       await branch.locator('.route-book-inspect').tap();
  71  |       await expect(inspection).toBeVisible();
  72  |       await inspection.locator('.route-inspection-relations button').first().click();
  73  |       await expect(inspection.locator('h2')).toBeFocused();
  74  |       await page.keyboard.press('Escape');
  75  |       await expect(branch.locator('.route-book-inspect')).toBeFocused();
  76  |       expect(posts).toBe(0);
  77  |       expect(await read(page)).toEqual(before);
  78  |     });
  79  | 
  80  |     test(`A75 ${pack} ${language} map and list retain visible fallback when both icons fail`, async ({
  81  |       page,
  82  |     }) => {
  83  |       await packPreference(page, pack);
  84  |       await page.goto('/');
  85  |       if (language === 'en') await changeLanguage(page, language);
  86  |       await page.locator('.portal-enter').click();
  87  |       await startExpedition(page, language);
  88  |       const toggle = page.locator('.map-view-toggle');
  89  |       await expect(toggle.locator('img')).toHaveAttribute('data-art', 'ui.missions');
  90  |       const missions = await toggle.locator('img').getAttribute('src');
  91  |       await toggle.click();
  92  |       await expect(toggle.locator('img')).toHaveAttribute('data-art', 'ui.map');
  93  |       const map = await toggle.locator('img').getAttribute('src');
  94  |       for (const source of [missions, map]) {
  95  |         expect(source).toBeTruthy();
  96  |         await page.route(new URL(source!, page.url()).href, (route) => route.abort());
  97  |       }
  98  |       const before = await read(page);
  99  |       await page.reload();
  100 |       await expect(toggle).toBeVisible();
  101 |       try {
> 102 |         await expect(toggle.locator('img')).toHaveCount(0);
      |                                             ^ Error: expect(locator).toHaveCount(expected) failed
  103 |       } finally {
  104 |         const debug = await toggle.evaluate((e) => ({
  105 |           html: e.outerHTML,
  106 |           fallback: (() => {
  107 |             const s = e.querySelector('.map-view-fallback')!;
  108 |             const c = getComputedStyle(s);
  109 |             const r = s.getBoundingClientRect();
  110 |             return {
  111 |               display: c.display,
  112 |               visibility: c.visibility,
  113 |               opacity: c.opacity,
  114 |               width: r.width,
  115 |               height: r.height,
  116 |             };
  117 |           })(),
  118 |         }));
  119 |         const evidence = resolve('docs/arcana/experience-fixes-2026-10-17/evidence/linux');
  120 |         await mkdir(evidence, { recursive: true });
  121 |         await writeFile(
  122 |           resolve(evidence, `icon-fallback-${pack}-${language}.json`),
  123 |           JSON.stringify(
  124 |             { sha: process.env.GITHUB_SHA, pack, language, missions, map, debug },
  125 |             null,
  126 |             2,
  127 |           ),
  128 |         );
  129 |         await test.info().attach('icon-fallback-state', {
  130 |           body: JSON.stringify({ pack, language, missions, map, debug }, null, 2),
  131 |           contentType: 'application/json',
  132 |         });
  133 |       }
  134 |       await expect(toggle.locator('.map-view-fallback')).toBeVisible();
  135 |       await expect(toggle).toHaveText(language === 'es' ? 'Ver lista de nodos' : 'View node list');
  136 |       await toggle.focus();
  137 |       await page.keyboard.press('Enter');
  138 |       await expect(page.locator('.route-list')).toBeVisible();
  139 |       await expect(toggle.locator('img')).toHaveCount(0);
  140 |       await expect(toggle.locator('.map-view-fallback')).toBeVisible();
  141 |       await expect(toggle).toHaveText(language === 'es' ? 'Ver mapa' : 'View map');
  142 |       expect(await read(page)).toEqual(before);
  143 |     });
  144 |   }
  145 | 
  146 | for (const language of ['es', 'en'] as const)
  147 |   for (const system of [false, true])
  148 |     for (const own of [false, true])
  149 |       test(`A75 ${language} actual settings system=${system} own=${own} persists own choice and respects system`, async ({
  150 |         page,
  151 |       }) => {
  152 |         await page.emulateMedia({ reducedMotion: system ? 'reduce' : 'no-preference' });
  153 |         await page.addInitScript((initial) => {
  154 |           if (localStorage.getItem('arcana-reduced-motion') === null)
  155 |             localStorage.setItem('arcana-reduced-motion', String(initial));
  156 |         }, own);
  157 |         await page.goto('/');
  158 |         if (language === 'en') await changeLanguage(page, language);
  159 |         await page.locator('.portal-enter').click();
  160 |         const before = await read(page);
  161 |         let dialog = await settings(page);
  162 |         const choice = () => dialog.locator('.settings-motion');
  163 |         await expect(choice()).toHaveAttribute('aria-pressed', String(own));
  164 |         await expect(dialog.locator('#settings-motion-state')).toHaveAttribute(
  165 |           'data-motion-system',
  166 |           String(system),
  167 |         );
  168 |         await expect(dialog.locator('#settings-motion-state')).toHaveAttribute(
  169 |           'data-motion-effective',
  170 |           String(system || own),
  171 |         );
  172 |         await choice().click();
  173 |         await expect(choice()).toHaveAttribute('aria-pressed', String(!own));
  174 |         await expect(page.locator('.game-shell')).toHaveAttribute(
  175 |           'data-reduced',
  176 |           String(system || !own),
  177 |         );
  178 |         await dialog
  179 |           .getByRole('button', {
  180 |             name: language === 'es' ? 'Callejón Diagón' : 'Diagon Alley',
  181 |             exact: true,
  182 |           })
  183 |           .click();
  184 |         await expect(choice()).toHaveAttribute('aria-pressed', String(!own));
  185 |         await expect(dialog.locator('#settings-motion-state')).toHaveAttribute(
  186 |           'data-motion-effective',
  187 |           String(system || !own),
  188 |         );
  189 |         await page.reload();
  190 |         dialog = await settings(page);
  191 |         await expect(choice()).toHaveAttribute('aria-pressed', String(!own));
  192 |         await expect(dialog.locator('#settings-motion-state')).toHaveAttribute(
  193 |           'data-motion-effective',
  194 |           String(system || !own),
  195 |         );
  196 |         expect(await read(page)).toEqual(before);
  197 |       });
  198 | 
  199 | test('A75 settings preference during paused replay never restarts the confirmed log or alters resources', async ({
  200 |   page,
  201 | }) => {
  202 |   await page.emulateMedia({ reducedMotion: 'no-preference' });
```