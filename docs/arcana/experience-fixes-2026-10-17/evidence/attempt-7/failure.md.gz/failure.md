# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: map-settings-a75.spec.ts >> A75 es actual settings system=false own=false persists own choice and respects system
- Location: tests/browser-experience-fixes/map-settings-a75.spec.ts:163:7

# Error details

```
Error: expect(received).toEqual(expected) // deep equality

Expected: undefined
Received: {"copies": [{"catalogVersion": 2, "copyId": "starter:apprentice", "origin": "starter", "sourceId": "starter-kit", "wizard": {"context": {"en": "ARCANA trial identity; provisional portrait.", "es": "Identidad de ensayo ARCANA; retrato provisional."}, "id": "apprentice", "name": {"en": "Alchemy Apprentice", "es": "Aprendiz de Alquimia"}, "rarity": "common", "stars": 1, "stats": {"maxHp": 100, "maxMana": 40, "power": 10, "speed": 6}}}], "inventory": {"crowns": 50, "equipment": [{"core": null, "id": "starter:wand", "kind": "wand", "multiplier": 1, "powerBonus": 2, "version": 1, "wood": "birch"}, {"id": "starter:broom", "initiative": 3, "kind": "broom", "model": "cadet-zephyr", "version": 1}], "essence": {"cursor": 1792261747478, "points": 50}, "goldKeys": 0, "products": []}, "playerId": "trial-19ccfa68-1f9e-4c58-9592-a80db7589a4f", "receipts": [{"catalogVersion": 2, "copyId": "starter:apprentice", "equipmentIds": ["starter:wand", "starter:broom"], "id": "starter-kit", "kind": "starter-kit", "wizard": {"context": {"en": "ARCANA trial identity; provisional portrait.", "es": "Identidad de ensayo ARCANA; retrato provisional."}, "id": "apprentice", "name": {"en": "Alchemy Apprentice", "es": "Aprendiz de Alquimia"}, "rarity": "common", "stars": 1, "stats": {"maxHp": 100, "maxMana": 40, "power": 10, "speed": 6}}}], "revision": 1, "schemaVersion": 1, "team": {"copyIds": ["starter:apprentice"], "loadouts": [{"broomId": "starter:broom", "copyId": "starter:apprentice", "wandId": "starter:wand"}]}}
```

# Page snapshot

```yaml
- generic [ref=f1e3]:
  - link "Saltar al contenido" [ref=f1e4] [cursor=pointer]:
    - /url: "#content"
  - banner [ref=f1e5]:
    - heading "Callejón Diagón" [level=1] [ref=f1e6]
    - generic [ref=f1e7]:
      - status [ref=f1e8]
      - button "Una noche encantada" [ref=f1e9] [cursor=pointer]
    - dialog "Ajustes" [ref=f1e12]:
      - button "Cerrar" [active] [ref=f1e13] [cursor=pointer]
      - banner [ref=f1e16]:
        - heading "Ajustes" [level=2] [ref=f1e18]
      - group "Idioma" [ref=f1e19]:
        - button "Español" [pressed] [ref=f1e21] [cursor=pointer]:
          - generic [aria-hidden] [ref=f1e22]: ES
        - button "English" [ref=f1e25] [cursor=pointer]:
          - generic [aria-hidden] [ref=f1e26]: EN
      - group "Mundo" [ref=f1e28]:
        - button "Callejón Diagón" [pressed] [ref=f1e30] [cursor=pointer]:
          - generic [aria-hidden] [ref=f1e31]: ✦
        - button "ARCANA" [ref=f1e34] [cursor=pointer]:
          - generic [aria-hidden] [ref=f1e35]: ☽
      - button "Reducir movimiento por mi elección" [pressed] [ref=f1e37] [cursor=pointer]
      - paragraph [ref=f1e40]: Movimiento reducido activo.
      - button "Tu partida" [ref=f1e41] [cursor=pointer]
  - status [ref=f1e44]
  - generic [ref=f1e45]:
    - strong [ref=f1e46]:
      - generic "Galeones" [ref=f1e48]: "50"
    - generic [ref=f1e49]:
      - generic [ref=f1e50]:
        - generic [ref=f1e52]: Energía
        - text: 50 / 50
        - meter "Energía mágica" [ref=f1e53]
      - generic [ref=f1e54]: Energía al máximo.
      - button "Actualizar Energía" [ref=f1e55] [cursor=pointer]
    - generic [ref=f1e58]:
      - strong [aria-hidden] [ref=f1e60]: "0"
      - generic [ref=f1e61]: 0 Llaves de Oro
  - main [ref=f1e62]:
    - status [ref=f1e63]
    - generic [ref=f1e64]:
      - generic:
        - complementary "Siguiente objetivo":
          - generic:
            - heading "Tu primera aventura" [level=3]
            - group [ref=f1e65]:
              - generic "Siguiente objetivo" [ref=f1e66] [cursor=pointer]: "?"
      - region "Prepara tu expedición" [ref=f1e68]:
        - heading "Prepara tu expedición" [level=2] [ref=f1e70]
        - group [ref=f1e71]:
          - generic "Desafío de la expedición" [ref=f1e72] [cursor=pointer]:
            - generic [ref=f1e74]: Descubrimiento
            - generic [aria-hidden] [ref=f1e75]: ⌄
        - generic "0/5 acompañantes" [ref=f1e76]:
          - generic "Puesto 1 vacío" [ref=f1e78]: "1"
          - generic "Puesto 2 vacío" [ref=f1e80]: "2"
          - generic "Puesto 3 vacío" [ref=f1e82]: "3"
          - generic "Puesto 4 vacío" [ref=f1e84]: "4"
          - generic "Puesto 5 vacío" [ref=f1e86]: "5"
        - generic [ref=f1e87]:
          - generic [ref=f1e88]:
            - generic [aria-hidden] [ref=f1e89]: 0/5
            - generic [ref=f1e90]: 0/5 acompañantes
          - group [ref=f1e91]:
            - generic "Cómo formar el equipo" [ref=f1e92] [cursor=pointer]:
              - generic [aria-hidden] [ref=f1e93]: "?"
        - group [ref=f1e94]:
          - generic "Sinergias del equipo" [ref=f1e95] [cursor=pointer]: Sin sinergias activas
        - generic [ref=f1e99]:
          - heading "Elige quién te acompaña" [level=3] [ref=f1e100]
          - generic [ref=f1e102]:
            - button "Harry Potter · copia 1 · elegir o retirar" [ref=f1e103] [cursor=pointer]:
              - generic [ref=f1e105]: Harry Potter
              - generic [ref=f1e106]: Copia 1
            - button "Consultar Harry Potter" [ref=f1e107] [cursor=pointer]
        - button "Entrar al mapa" [disabled] [ref=f1e111]
  - navigation "Navegación principal" [ref=f1e114]:
    - button "Mapa" [ref=f1e115] [cursor=pointer]
    - button "Álbum de Cromos" [ref=f1e118] [cursor=pointer]
    - button "Callejón" [ref=f1e121] [cursor=pointer]
    - button "Misiones" [ref=f1e124] [cursor=pointer]
```

# Test source

```ts
  110 |       await expect(toggle).toBeVisible();
  111 |       await failIcon();
  112 |       try {
  113 |         await expect(toggle.locator('img')).toHaveCount(0);
  114 |       } finally {
  115 |         const debug = await toggle.evaluate((e) => ({
  116 |           html: e.outerHTML,
  117 |           fallback: (() => {
  118 |             const s = e.querySelector('.map-view-fallback')!;
  119 |             const c = getComputedStyle(s);
  120 |             const r = s.getBoundingClientRect();
  121 |             return {
  122 |               display: c.display,
  123 |               visibility: c.visibility,
  124 |               opacity: c.opacity,
  125 |               width: r.width,
  126 |               height: r.height,
  127 |             };
  128 |           })(),
  129 |         }));
  130 |         const evidence = resolve('docs/arcana/experience-fixes-2026-10-17/evidence/linux');
  131 |         await mkdir(evidence, { recursive: true });
  132 |         await writeFile(
  133 |           resolve(evidence, `icon-fallback-${pack}-${language}.json`),
  134 |           JSON.stringify(
  135 |             { sha: process.env.GITHUB_SHA, pack, language, missions, map, debug },
  136 |             null,
  137 |             2,
  138 |           ),
  139 |         );
  140 |         await test.info().attach('icon-fallback-state', {
  141 |           body: JSON.stringify({ pack, language, missions, map, debug }, null, 2),
  142 |           contentType: 'application/json',
  143 |         });
  144 |       }
  145 |       await expect(toggle.locator('.map-view-fallback')).toBeVisible();
  146 |       await expect(toggle).toHaveText(language === 'es' ? 'Ver lista de nodos' : 'View node list');
  147 |       await toggle.focus();
  148 |       await page.keyboard.press('Enter');
  149 |       await expect(page.locator('.route-list')).toBeVisible();
  150 |       await failIcon();
  151 |       await expect(toggle.locator('img')).toHaveCount(0);
  152 |       await expect(toggle.locator('.map-view-fallback')).toBeVisible();
  153 |       await expect(toggle).toHaveText(
  154 |         language === 'es' ? 'Ver mapa ramificado' : 'View branching map',
  155 |       );
  156 |       expect(await read(page)).toEqual(before);
  157 |     });
  158 |   }
  159 | 
  160 | for (const language of ['es', 'en'] as const)
  161 |   for (const system of [false, true])
  162 |     for (const own of [false, true])
  163 |       test(`A75 ${language} actual settings system=${system} own=${own} persists own choice and respects system`, async ({
  164 |         page,
  165 |       }) => {
  166 |         await page.emulateMedia({ reducedMotion: system ? 'reduce' : 'no-preference' });
  167 |         await page.addInitScript((initial) => {
  168 |           if (localStorage.getItem('arcana-reduced-motion') === null)
  169 |             localStorage.setItem('arcana-reduced-motion', String(initial));
  170 |         }, own);
  171 |         await page.goto('/');
  172 |         if (language === 'en') await changeLanguage(page, language);
  173 |         await page.locator('.portal-enter').click();
  174 |         const before = await read(page);
  175 |         let dialog = await settings(page);
  176 |         const choice = () => dialog.locator('.settings-motion');
  177 |         await expect(choice()).toHaveAttribute('aria-pressed', String(own));
  178 |         await expect(dialog.locator('#settings-motion-state')).toHaveAttribute(
  179 |           'data-motion-system',
  180 |           String(system),
  181 |         );
  182 |         await expect(dialog.locator('#settings-motion-state')).toHaveAttribute(
  183 |           'data-motion-effective',
  184 |           String(system || own),
  185 |         );
  186 |         await choice().click();
  187 |         await expect(choice()).toHaveAttribute('aria-pressed', String(!own));
  188 |         await expect(page.locator('.game-shell')).toHaveAttribute(
  189 |           'data-reduced',
  190 |           String(system || !own),
  191 |         );
  192 |         await dialog
  193 |           .getByRole('button', {
  194 |             name: language === 'es' ? 'Callejón Diagón' : 'Diagon Alley',
  195 |             exact: true,
  196 |           })
  197 |           .click();
  198 |         await expect(choice()).toHaveAttribute('aria-pressed', String(!own));
  199 |         await expect(dialog.locator('#settings-motion-state')).toHaveAttribute(
  200 |           'data-motion-effective',
  201 |           String(system || !own),
  202 |         );
  203 |         await page.reload();
  204 |         dialog = await settings(page);
  205 |         await expect(choice()).toHaveAttribute('aria-pressed', String(!own));
  206 |         await expect(dialog.locator('#settings-motion-state')).toHaveAttribute(
  207 |           'data-motion-effective',
  208 |           String(system || !own),
  209 |         );
> 210 |         expect(await read(page)).toEqual(before);
      |                                  ^ Error: expect(received).toEqual(expected) // deep equality
  211 |       });
  212 | 
  213 | test('A75 settings preference during paused replay never restarts the confirmed log or alters resources', async ({
  214 |   page,
  215 | }) => {
  216 |   await page.emulateMedia({ reducedMotion: 'no-preference' });
  217 |   await page.goto('/');
  218 |   await page.locator('.portal-enter').click();
  219 |   await startExpedition(page);
  220 |   const node = await reachNode(page, 'duel', 'es');
  221 |   await page.locator(`[data-node="${node}"]`).click();
  222 |   await confirmEvent(page, 'es');
  223 |   await page.getByRole('button', { name: 'Pausa', exact: true }).click();
  224 |   const arena = page.locator('[data-replay-cursor]');
  225 |   const cursor = await arena.getAttribute('data-replay-cursor');
  226 |   const before = await read(page);
  227 |   const dialog = await settings(page);
  228 |   await dialog.locator('.settings-motion').click();
  229 |   await expect(page.locator('.game-shell')).toHaveAttribute('data-reduced', 'true');
  230 |   await dialog.getByRole('button', { name: 'Cerrar', exact: true }).click();
  231 |   const total = await arena.getAttribute('data-replay-total');
  232 |   expect(Number(total)).toBeGreaterThanOrEqual(Number(cursor));
  233 |   await expect(arena).toHaveAttribute('data-replay-cursor', total!);
  234 |   const resumedSettings = await settings(page);
  235 |   await resumedSettings.locator('.settings-motion').click();
  236 |   await resumedSettings.getByRole('button', { name: 'Cerrar', exact: true }).click();
  237 |   await expect(arena).toHaveAttribute('data-replay-cursor', total!);
  238 |   expect(await read(page)).toEqual(before);
  239 | });
  240 | 
```