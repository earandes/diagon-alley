# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: map-settings-a75.spec.ts >> A75 diagon-alley es map and list retain visible fallback when both icons fail
- Location: tests/browser-experience-fixes/map-settings-a75.spec.ts:80:5

# Error details

```
Error: expect(locator).toHaveText(expected) failed

Locator:  locator('.map-view-toggle')
Expected: "Ver mapa"
Received: "Ver mapa ramificado"
Timeout:  12000ms

Call log:
  - Expect "toHaveText" locator('.map-view-toggle') with timeout 12000ms
  - waiting for locator('.map-view-toggle')
    28 × locator resolved to <button class="map-view-toggle" title="Ver mapa ramificado" aria-label="Ver mapa ramificado">…</button>
       - unexpected value "Ver mapa ramificado"

```

```yaml
- button "Ver mapa ramificado"
```

# Test source

```ts
  53  |       await expect(inspection).toContainText(language === 'es' ? 'Solo consulta' : 'Read only');
  54  |       await expect(inspection.locator('.node-confirm-action')).toHaveCount(0);
  55  |       if (language === 'es' && pack === 'diagon-alley') await selectedA75(page, 'route-inspection');
  56  |       await page.keyboard.press('Escape');
  57  |       await expect(inspection).toHaveCount(0);
  58  |       await expect(future).toBeFocused();
  59  |       await page.locator('.map-view-toggle').click();
  60  |       const entries = page.locator('.route-book-entry');
  61  |       expect(await entries.count()).toBe(before.exploration.run.graph.nodes.length);
  62  |       const names = await entries
  63  |         .locator('[data-node]')
  64  |         .evaluateAll((buttons) => buttons.map((button) => button.getAttribute('aria-label')));
  65  |       expect(new Set(names).size).toBe(names.length);
  66  |       const branch = entries.filter({ has: page.locator('[data-node-state="locked"]') }).first();
  67  |       await branch.locator('summary').tap();
  68  |       await expect(branch).toContainText(language === 'es' ? 'Desde' : 'From');
  69  |       await expect(branch).toContainText(language === 'es' ? 'Continúa hacia' : 'Continues to');
  70  |       await branch.locator('.route-book-inspect').tap();
  71  |       await expect(inspection).toBeVisible();
  72  |       await inspection.locator('.route-inspection-relations button').first().click();
  73  |       await expect(inspection.locator('h2')).toBeFocused();
  74  |       await page.keyboard.press('Escape');
  75  |       await expect(branch.locator('.route-book-inspect')).toBeFocused();
  76  |       expect(posts).toBe(0);
  77  |       expect(await read(page)).toEqual(before);
  78  |     });
  79  | 
  80  |     test(`A75 ${pack} ${language} map and list retain visible fallback when both icons fail`, async ({
  81  |       page,
  82  |     }) => {
  83  |       await packPreference(page, pack);
  84  |       await page.goto('/');
  85  |       if (language === 'en') await changeLanguage(page, language);
  86  |       await page.locator('.portal-enter').click();
  87  |       await startExpedition(page, language);
  88  |       const toggle = page.locator('.map-view-toggle');
  89  |       await expect(toggle.locator('img')).toHaveAttribute('data-art', 'ui.missions');
  90  |       const missions = await toggle.locator('img').getAttribute('src');
  91  |       await toggle.click();
  92  |       await expect(toggle.locator('img')).toHaveAttribute('data-art', 'ui.map');
  93  |       const map = await toggle.locator('img').getAttribute('src');
  94  |       expect(missions).toBeTruthy();
  95  |       expect(map).toBeTruthy();
  96  |       // These assets may be inlined data: SVGs; HTTP interception cannot fail them.
  97  |       // Replace only this control's image with a real 404 and let Artwork's native
  98  |       // error handler run. No synthetic success or forced fallback visibility.
  99  |       await page.route('**/a75-missing-icon.svg', (route) =>
  100 |         route.fulfill({ status: 404, body: '' }),
  101 |       );
  102 |       const failIcon = async () => {
  103 |         await expect(toggle.locator('img')).toBeVisible();
  104 |         await toggle.locator('img').evaluate((image) => {
  105 |           image.setAttribute('src', '/a75-missing-icon.svg');
  106 |         });
  107 |       };
  108 |       const before = await read(page);
  109 |       await page.reload();
  110 |       await expect(toggle).toBeVisible();
  111 |       await failIcon();
  112 |       try {
  113 |         await expect(toggle.locator('img')).toHaveCount(0);
  114 |       } finally {
  115 |         const debug = await toggle.evaluate((e) => ({
  116 |           html: e.outerHTML,
  117 |           fallback: (() => {
  118 |             const s = e.querySelector('.map-view-fallback')!;
  119 |             const c = getComputedStyle(s);
  120 |             const r = s.getBoundingClientRect();
  121 |             return {
  122 |               display: c.display,
  123 |               visibility: c.visibility,
  124 |               opacity: c.opacity,
  125 |               width: r.width,
  126 |               height: r.height,
  127 |             };
  128 |           })(),
  129 |         }));
  130 |         const evidence = resolve('docs/arcana/experience-fixes-2026-10-17/evidence/linux');
  131 |         await mkdir(evidence, { recursive: true });
  132 |         await writeFile(
  133 |           resolve(evidence, `icon-fallback-${pack}-${language}.json`),
  134 |           JSON.stringify(
  135 |             { sha: process.env.GITHUB_SHA, pack, language, missions, map, debug },
  136 |             null,
  137 |             2,
  138 |           ),
  139 |         );
  140 |         await test.info().attach('icon-fallback-state', {
  141 |           body: JSON.stringify({ pack, language, missions, map, debug }, null, 2),
  142 |           contentType: 'application/json',
  143 |         });
  144 |       }
  145 |       await expect(toggle.locator('.map-view-fallback')).toBeVisible();
  146 |       await expect(toggle).toHaveText(language === 'es' ? 'Ver lista de nodos' : 'View node list');
  147 |       await toggle.focus();
  148 |       await page.keyboard.press('Enter');
  149 |       await expect(page.locator('.route-list')).toBeVisible();
  150 |       await failIcon();
  151 |       await expect(toggle.locator('img')).toHaveCount(0);
  152 |       await expect(toggle.locator('.map-view-fallback')).toBeVisible();
> 153 |       await expect(toggle).toHaveText(language === 'es' ? 'Ver mapa' : 'View map');
      |                            ^ Error: expect(locator).toHaveText(expected) failed
  154 |       expect(await read(page)).toEqual(before);
  155 |     });
  156 |   }
  157 | 
  158 | for (const language of ['es', 'en'] as const)
  159 |   for (const system of [false, true])
  160 |     for (const own of [false, true])
  161 |       test(`A75 ${language} actual settings system=${system} own=${own} persists own choice and respects system`, async ({
  162 |         page,
  163 |       }) => {
  164 |         await page.emulateMedia({ reducedMotion: system ? 'reduce' : 'no-preference' });
  165 |         await page.addInitScript((initial) => {
  166 |           if (localStorage.getItem('arcana-reduced-motion') === null)
  167 |             localStorage.setItem('arcana-reduced-motion', String(initial));
  168 |         }, own);
  169 |         await page.goto('/');
  170 |         if (language === 'en') await changeLanguage(page, language);
  171 |         await page.locator('.portal-enter').click();
  172 |         const before = await read(page);
  173 |         let dialog = await settings(page);
  174 |         const choice = () => dialog.locator('.settings-motion');
  175 |         await expect(choice()).toHaveAttribute('aria-pressed', String(own));
  176 |         await expect(dialog.locator('#settings-motion-state')).toHaveAttribute(
  177 |           'data-motion-system',
  178 |           String(system),
  179 |         );
  180 |         await expect(dialog.locator('#settings-motion-state')).toHaveAttribute(
  181 |           'data-motion-effective',
  182 |           String(system || own),
  183 |         );
  184 |         await choice().click();
  185 |         await expect(choice()).toHaveAttribute('aria-pressed', String(!own));
  186 |         await expect(page.locator('.game-shell')).toHaveAttribute(
  187 |           'data-reduced',
  188 |           String(system || !own),
  189 |         );
  190 |         await dialog
  191 |           .getByRole('button', {
  192 |             name: language === 'es' ? 'Callejón Diagón' : 'Diagon Alley',
  193 |             exact: true,
  194 |           })
  195 |           .click();
  196 |         await expect(choice()).toHaveAttribute('aria-pressed', String(!own));
  197 |         await expect(dialog.locator('#settings-motion-state')).toHaveAttribute(
  198 |           'data-motion-effective',
  199 |           String(system || !own),
  200 |         );
  201 |         await page.reload();
  202 |         dialog = await settings(page);
  203 |         await expect(choice()).toHaveAttribute('aria-pressed', String(!own));
  204 |         await expect(dialog.locator('#settings-motion-state')).toHaveAttribute(
  205 |           'data-motion-effective',
  206 |           String(system || !own),
  207 |         );
  208 |         expect(await read(page)).toEqual(before);
  209 |       });
  210 | 
  211 | test('A75 settings preference during paused replay never restarts the confirmed log or alters resources', async ({
  212 |   page,
  213 | }) => {
  214 |   await page.emulateMedia({ reducedMotion: 'no-preference' });
  215 |   await page.goto('/');
  216 |   await page.locator('.portal-enter').click();
  217 |   await startExpedition(page);
  218 |   const node = await reachNode(page, 'duel', 'es');
  219 |   await page.locator(`[data-node="${node}"]`).click();
  220 |   await confirmEvent(page, 'es');
  221 |   await page.getByRole('button', { name: 'Pausa', exact: true }).click();
  222 |   const arena = page.locator('[data-replay-cursor]');
  223 |   const cursor = await arena.getAttribute('data-replay-cursor');
  224 |   const before = await read(page);
  225 |   const dialog = await settings(page);
  226 |   await dialog.locator('.settings-motion').click();
  227 |   await expect(page.locator('.game-shell')).toHaveAttribute('data-reduced', 'true');
  228 |   await dialog.getByRole('button', { name: 'Cerrar', exact: true }).click();
  229 |   const total = await arena.getAttribute('data-replay-total');
  230 |   expect(Number(total)).toBeGreaterThanOrEqual(Number(cursor));
  231 |   await expect(arena).toHaveAttribute('data-replay-cursor', total!);
  232 |   const resumedSettings = await settings(page);
  233 |   await resumedSettings.locator('.settings-motion').click();
  234 |   await resumedSettings.getByRole('button', { name: 'Cerrar', exact: true }).click();
  235 |   await expect(arena).toHaveAttribute('data-replay-cursor', total!);
  236 |   expect(await read(page)).toEqual(before);
  237 | });
  238 | 
```